"use client";

import { useState, useEffect } from "react";

interface Analytics {
  overview: { totalEvents: number; uniqueSessions: number; activeSessions: number; leads: number };
  eventBreakdown: { event_type: string; count: number }[];
  topPages: { page: string; count: number }[];
  topServices: { service: string; count: number }[];
  deviceBreakdown: { device: string; count: number }[];
  sourceBreakdown: { source: string; count: number }[];
  recentEvents: { event_type: string; page: string; service: string; device: string; created_at: string }[];
  conversions: { visitors: number; service_views: number; cta_clicks: number; contacts: number };
}

export default function AdminAnalyticsPage() {
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [period, setPeriod] = useState("7d");

  useEffect(() => {
    fetch(`/api/analytics?period=${period}`).then((r) => r.json()).then(setAnalytics).catch(() => {});
  }, [period]);

  if (!analytics) return <div className="text-text-muted">Loading analytics...</div>;

  const convRate = analytics.conversions?.visitors
    ? ((analytics.conversions.contacts / analytics.conversions.visitors) * 100).toFixed(1)
    : "0";

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold">Analytics Dashboard</h1>
        <select value={period} onChange={(e) => setPeriod(e.target.value)} className="input-field text-sm w-40">
          <option value="1d">Last 24 Hours</option>
          <option value="7d">Last 7 Days</option>
          <option value="30d">Last 30 Days</option>
          <option value="90d">Last 90 Days</option>
        </select>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        {[
          { label: "Total Events", value: analytics.overview.totalEvents, color: "text-primary-light" },
          { label: "Sessions", value: analytics.overview.uniqueSessions, color: "text-accent" },
          { label: "Active Now", value: analytics.overview.activeSessions, color: "text-gold" },
          { label: "Leads", value: analytics.overview.leads, color: "text-accent" },
          { label: "Conversion Rate", value: `${convRate}%`, color: "text-primary-light" },
        ].map((s) => (
          <div key={s.label} className="card-glass rounded-xl p-4">
            <p className="text-xs text-text-muted uppercase">{s.label}</p>
            <p className={`text-2xl font-bold mt-1 ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* 3D-style Visualizations (HTML-based) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Visitor Globe Placeholder */}
        <div className="card-glass rounded-xl p-6">
          <h2 className="font-bold text-foreground mb-4">Visitor Activity Globe</h2>
          <div className="relative h-48 bg-surface rounded-xl flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 rounded-xl" />
            <div className="relative text-center">
              <div className="w-32 h-32 mx-auto rounded-full border border-border flex items-center justify-center relative">
                <div className="absolute w-full h-full rounded-full border border-primary/30 animate-pulse" />
                {analytics.recentEvents.slice(0, 8).map((_, i) => (
                  <div
                    key={i}
                    className="absolute w-2 h-2 rounded-full bg-accent animate-pulse-glow"
                    style={{
                      top: `${20 + Math.random() * 60}%`,
                      left: `${20 + Math.random() * 60}%`,
                      animationDelay: `${i * 0.3}s`,
                    }}
                  />
                ))}
                <span className="text-3xl font-bold text-foreground">{analytics.overview.activeSessions}</span>
              </div>
              <p className="text-xs text-text-muted mt-3">Active Sessions</p>
            </div>
          </div>
        </div>

        {/* Traffic Orbit */}
        <div className="card-glass rounded-xl p-6">
          <h2 className="font-bold text-foreground mb-4">Traffic Sources Orbit</h2>
          <div className="relative h-48 bg-surface rounded-xl flex items-center justify-center">
            <div className="relative w-40 h-40">
              <div className="absolute inset-0 rounded-full border border-border" />
              <div className="absolute inset-4 rounded-full border border-border" />
              <div className="absolute inset-8 rounded-full border border-border" />
              {analytics.sourceBreakdown.slice(0, 6).map((s, i) => {
                const angle = (i / analytics.sourceBreakdown.length) * 360;
                const radius = 50 + (i % 3) * 15;
                const x = Math.cos((angle * Math.PI) / 180) * radius;
                const y = Math.sin((angle * Math.PI) / 180) * radius;
                return (
                  <div
                    key={s.source}
                    className="absolute w-3 h-3 rounded-full bg-primary-light"
                    style={{ top: `calc(50% + ${y}px - 6px)`, left: `calc(50% + ${x}px - 6px)` }}
                    title={`${s.source}: ${s.count}`}
                  />
                );
              })}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-primary to-accent" />
              </div>
            </div>
          </div>
          <div className="flex flex-wrap gap-3 mt-4">
            {analytics.sourceBreakdown.map((s) => (
              <span key={s.source} className="text-xs text-text-muted">
                <span className="inline-block w-2 h-2 rounded-full bg-primary-light mr-1" />
                {s.source}: {s.count}
              </span>
            ))}
          </div>
        </div>

        {/* Conversion Funnel */}
        <div className="card-glass rounded-xl p-6">
          <h2 className="font-bold text-foreground mb-4">Conversion Funnel</h2>
          <div className="space-y-4">
            {[
              { label: "VISITORS", value: analytics.conversions?.visitors || 0, width: "100%", color: "from-primary to-primary-light" },
              { label: "SERVICE VIEWS", value: analytics.conversions?.service_views || 0, width: "75%", color: "from-primary-light to-accent" },
              { label: "CTA CLICKS", value: analytics.conversions?.cta_clicks || 0, width: "50%", color: "from-accent to-accent-dark" },
              { label: "LEADS", value: analytics.conversions?.contacts || 0, width: "25%", color: "from-accent-dark to-gold" },
            ].map((step) => (
              <div key={step.label}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-text-muted font-semibold tracking-wider">{step.label}</span>
                  <span className="text-foreground font-bold">{step.value}</span>
                </div>
                <div className="h-6 bg-surface rounded-lg overflow-hidden flex items-center">
                  <div className={`h-full bg-gradient-to-r ${step.color} rounded-lg transition-all duration-700 flex items-center justify-end pr-2`} style={{ width: step.width, minWidth: step.value > 0 ? "2rem" : "0" }}>
                    {step.value > 0 && <span className="text-[10px] text-white font-bold">{step.value}</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Device Breakdown */}
        <div className="card-glass rounded-xl p-6">
          <h2 className="font-bold text-foreground mb-4">Device Categories</h2>
          <div className="space-y-4">
            {analytics.deviceBreakdown.map((d) => {
              const total = analytics.deviceBreakdown.reduce((a, b) => a + b.count, 0);
              const pct = total > 0 ? (d.count / total) * 100 : 0;
              return (
                <div key={d.device}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-text-muted capitalize">{d.device}</span>
                    <span className="text-foreground">{d.count} ({pct.toFixed(0)}%)</span>
                  </div>
                  <div className="h-3 bg-surface rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-primary to-accent rounded-full" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Top Services & Pages */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="card-glass rounded-xl p-6">
          <h2 className="font-bold text-foreground mb-4">Most Viewed Services</h2>
          <div className="space-y-2">
            {analytics.topServices.map((s, i) => (
              <div key={s.service} className="flex items-center gap-3 py-2">
                <span className="text-xs text-text-muted w-4">{i + 1}</span>
                <span className="text-sm text-foreground flex-1">{s.service}</span>
                <span className="text-sm text-accent font-medium">{s.count}</span>
              </div>
            ))}
            {analytics.topServices.length === 0 && <p className="text-text-muted text-sm">No data yet</p>}
          </div>
        </div>
        <div className="card-glass rounded-xl p-6">
          <h2 className="font-bold text-foreground mb-4">Most Viewed Pages</h2>
          <div className="space-y-2">
            {analytics.topPages.map((p, i) => (
              <div key={p.page} className="flex items-center gap-3 py-2">
                <span className="text-xs text-text-muted w-4">{i + 1}</span>
                <span className="text-sm text-foreground flex-1 truncate">{p.page}</span>
                <span className="text-sm text-accent font-medium">{p.count}</span>
              </div>
            ))}
            {analytics.topPages.length === 0 && <p className="text-text-muted text-sm">No data yet</p>}
          </div>
        </div>
      </div>

      {/* Recent Events */}
      <div className="card-glass rounded-xl p-6">
        <h2 className="font-bold text-foreground mb-4">Recent Events</h2>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-2 text-text-muted font-medium">Event</th>
                <th className="text-left py-2 text-text-muted font-medium">Page</th>
                <th className="text-left py-2 text-text-muted font-medium">Device</th>
                <th className="text-left py-2 text-text-muted font-medium">Time</th>
              </tr>
            </thead>
            <tbody>
              {analytics.recentEvents.map((e, i) => (
                <tr key={i} className="border-b border-border/50">
                  <td className="py-2 text-foreground">{e.event_type.replace(/_/g, " ")}</td>
                  <td className="py-2 text-text-muted">{e.page || "-"}</td>
                  <td className="py-2 text-text-muted capitalize">{e.device || "-"}</td>
                  <td className="py-2 text-text-muted">{new Date(e.created_at).toLocaleString()}</td>
                </tr>
              ))}
              {analytics.recentEvents.length === 0 && (
                <tr><td colSpan={4} className="py-4 text-center text-text-muted">No events recorded yet</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

"use client";

import { useState, useEffect, useCallback, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import SearchBar from "@/components/SearchBar";
import Link from "next/link";

interface SearchResult {
  type: string;
  title: string;
  slug: string;
  excerpt: string;
  url: string;
}

function SearchContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const q = searchParams.get("q") || "";
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);

  const search = useCallback(async (query: string) => {
    if (!query.trim()) { setResults([]); return; }
    setLoading(true);
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
      const data = await res.json();
      setResults(data.results || []);
    } catch { setResults([]); }
    setLoading(false);
  }, []);

  useEffect(() => { search(q); }, [q, search]);

  return (
    <div className="pt-24 min-h-screen">
      <div className="max-w-4xl mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold mb-8">
          Search Results {q && <span className="text-text-muted text-xl">for &quot;{q}&quot;</span>}
        </h1>

        <div className="mb-8">
          <SearchBar />
        </div>

        {loading && <p className="text-text-muted">Searching...</p>}

        {!loading && results.length > 0 && (
          <div className="space-y-4">
            {results.map((r, i) => (
              <Link
                key={i}
                href={r.url}
                className="block card-glass rounded-xl p-5 hover:border-primary/50 transition-all"
              >
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs bg-primary/20 text-primary-light px-2 py-0.5 rounded-full">{r.type}</span>
                </div>
                <h2 className="font-semibold text-foreground hover:text-accent transition-colors">{r.title}</h2>
                {r.excerpt && <p className="text-sm text-text-muted mt-1 line-clamp-2">{r.excerpt}</p>}
              </Link>
            ))}
          </div>
        )}

        {!loading && q && results.length === 0 && (
          <div className="text-center py-20">
            <p className="text-text-muted text-lg">No results found for &quot;{q}&quot;</p>
            <p className="text-text-muted text-sm mt-2">Try different keywords or browse our services.</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div className="pt-24 min-h-screen flex items-center justify-center text-text-muted">Loading...</div>}>
      <SearchContent />
    </Suspense>
  );
}

import { NextRequest } from "next/server";
import getDb from "@/lib/db";
import { generateId } from "@/lib/utils";

export async function GET() {
  try {
    const db = getDb();
    const leads = db.prepare("SELECT * FROM leads ORDER BY created_at DESC").all();
    return Response.json(leads);
  } catch {
    return Response.json({ error: "Failed" }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, email, phone, company, service, message, source, campaign } = body;

    if (!name || !email) {
      return Response.json({ error: "Name and email required" }, { status: 400 });
    }

    const db = getDb();
    const id = generateId();

    db.prepare(`
      INSERT INTO leads (id, name, email, phone, company, service, message, source, campaign)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(id, name, email, phone || null, company || null, service || null, message || null, source || "website", campaign || null);

    db.prepare(`
      INSERT INTO analytics_events (event_type, page, service, source, medium, campaign, session_id)
      VALUES ('contact_form_submitted', ?, ?, ?, ?, ?, ?)
    `).run(
      body.page || "/contact",
      service || null,
      source || "website",
      "form",
      campaign || null,
      body.session_id || null
    );

    return Response.json({ success: true, id });
  } catch {
    return Response.json({ error: "Failed" }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, status, notes } = body;
    if (!id) return Response.json({ error: "id required" }, { status: 400 });

    const db = getDb();
    if (status) {
      db.prepare("UPDATE leads SET status = ?, updated_at = datetime('now') WHERE id = ?").run(status, id);
    }
    if (notes !== undefined) {
      db.prepare("UPDATE leads SET notes = ?, updated_at = datetime('now') WHERE id = ?").run(notes, id);
    }
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: "Failed" }, { status: 500 });
  }
}

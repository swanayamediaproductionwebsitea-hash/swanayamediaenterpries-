import type { Metadata } from "next";
import { notFound } from "next/navigation";
import ScrollReveal from "@/components/ScrollReveal";
import Breadcrumbs from "@/components/Breadcrumbs";
import { getBlogBySlug, getBlogPosts, getServices } from "@/lib/queries";
import Link from "next/link";

export const dynamic = "force-dynamic";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const blog = getBlogBySlug(slug) as Record<string, string> | undefined;
  if (!blog) return {};
  return {
    title: blog.seo_title || blog.title,
    description: blog.seo_description || blog.excerpt || "",
    openGraph: {
      title: blog.og_title || blog.title,
      description: blog.og_description || blog.excerpt || "",
      type: "article",
      publishedTime: blog.published_at || undefined,
      images: blog.og_image ? [blog.og_image] : [],
    },
  };
}

export default async function BlogPostPage({ params }: Props) {
  const { slug } = await params;
  const blog = getBlogBySlug(slug) as Record<string, string> | undefined;
  if (!blog) notFound();

  const allBlogs = getBlogPosts() as { id: string; title: string; slug: string; excerpt: string }[];
  const relatedBlogs = allBlogs.filter((b) => b.slug !== slug).slice(0, 3);
  const relatedServices = getServices() as { id: string; title: string; slug: string }[];

  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: blog.title,
    description: blog.excerpt,
    datePublished: blog.published_at,
    author: blog.author_name ? { "@type": "Person", name: blog.author_name } : undefined,
    publisher: { "@type": "Organization", name: "Swanaya Media Enterprises" },
    url: `https://swanayamedia.com/insights/${blog.slug}`,
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }} />
      <div className="pt-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Insights", href: "/insights" }, { label: blog.title }]} />

          <ScrollReveal>
            <article className="max-w-4xl py-12">
              <div className="flex items-center gap-3 mb-4">
                {blog.category && <span className="text-xs bg-accent/10 text-accent px-2 py-0.5 rounded-full">{blog.category}</span>}
                {blog.published_at && (
                  <time className="text-xs text-text-muted" dateTime={blog.published_at}>
                    {new Date(blog.published_at).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
                  </time>
                )}
                {blog.read_time && <span className="text-xs text-text-muted">{blog.read_time} min read</span>}
              </div>

              <h1 className="text-4xl sm:text-5xl font-bold mb-6">{blog.title}</h1>

              {blog.author_name && (
                <div className="flex items-center gap-3 mb-8 pb-8 border-b border-border">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-sm font-bold text-white">
                    {blog.author_name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">{blog.author_name}</p>
                    <p className="text-xs text-text-muted">Swanaya Media Enterprises</p>
                  </div>
                </div>
              )}

              {blog.excerpt && (
                <p className="text-lg text-text-muted leading-relaxed mb-8 italic">{blog.excerpt}</p>
              )}

              {blog.aeo_answer && (
                <div className="card-glass rounded-xl p-6 mb-8">
                  <p className="text-foreground font-semibold mb-2">{blog.aeo_question || "Key Takeaway"}</p>
                  <p className="text-text-muted">{blog.aeo_answer}</p>
                </div>
              )}

              <div className="prose prose-invert max-w-none text-text-muted leading-relaxed" dangerouslySetInnerHTML={{ __html: blog.content || "" }} />
            </article>
          </ScrollReveal>
        </div>

        {/* Related Services */}
        {relatedServices.length > 0 && (
          <section className="py-16 bg-surface">
            <div className="max-w-4xl mx-auto px-4">
              <h2 className="text-2xl font-bold mb-6">Related Services</h2>
              <div className="flex flex-wrap gap-3">
                {relatedServices.slice(0, 4).map((s) => (
                  <Link key={s.id} href={`/services/${s.slug}`} className="card-glass rounded-xl px-5 py-3 text-sm text-foreground hover:text-accent hover:border-accent transition-all">
                    {s.title}
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Related Articles */}
        {relatedBlogs.length > 0 && (
          <section className="py-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <h2 className="text-2xl font-bold mb-8">Related Articles</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {relatedBlogs.map((b) => (
                  <Link key={b.id} href={`/insights/${b.slug}`} className="card-glass rounded-xl p-5 hover:border-primary/50 transition-all">
                    <h3 className="font-semibold text-foreground hover:text-accent transition-colors line-clamp-2">{b.title}</h3>
                    {b.excerpt && <p className="text-xs text-text-muted mt-2 line-clamp-2">{b.excerpt}</p>}
                  </Link>
                ))}
              </div>
            </div>
          </section>
        )}

        <section className="py-24 bg-gradient-to-r from-primary/10 to-accent/10">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Grow Your Business?</h2>
            <p className="text-text-muted mb-8">Let Swanaya Media Enterprises help you create a powerful digital presence.</p>
            <Link href="/contact" className="btn-primary inline-block text-lg px-10 py-4">
              Start a Project
            </Link>
          </div>
        </section>
      </div>
    </>
  );
}

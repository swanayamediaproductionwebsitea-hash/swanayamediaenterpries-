import Link from "next/link";

interface Props {
  title: string;
  slug: string;
  short_description?: string;
  client?: string;
  category?: string;
  thumbnail?: string;
}

export default function ProjectCard({ title, slug, short_description, client, category }: Props) {
  return (
    <Link
      href={`/projects/${slug}`}
      className="group block card-glass rounded-2xl overflow-hidden hover:border-primary/50 transition-all duration-300 hover:-translate-y-1"
    >
      <div className="h-48 bg-gradient-to-br from-primary/20 to-accent/10 flex items-center justify-center relative overflow-hidden">
        <div className="text-6xl opacity-20 group-hover:scale-110 transition-transform duration-500">✦</div>
        {category && (
          <span className="absolute top-4 left-4 text-xs bg-primary/80 text-white px-3 py-1 rounded-full">
            {category}
          </span>
        )}
      </div>
      <div className="p-6">
        <h3 className="text-lg font-bold text-foreground mb-2 group-hover:text-accent transition-colors">{title}</h3>
        {client && <p className="text-xs text-text-muted mb-2">Client: {client}</p>}
        {short_description && <p className="text-sm text-text-muted line-clamp-2">{short_description}</p>}
      </div>
    </Link>
  );
}

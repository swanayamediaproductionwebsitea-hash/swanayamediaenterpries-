"use client";

import { useState, useEffect } from "react";

interface Lead {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  service: string;
  message: string;
  source: string;
  status: string;
  notes: string;
  created_at: string;
}

const STATUSES = ["NEW", "CONTACTED", "QUALIFIED", "PROPOSAL", "WON", "LOST"];

export default function AdminLeadsPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("");
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);

  const fetchLeads = () => {
    fetch("/api/leads").then((r) => r.json()).then((d) => {
      setLeads(Array.isArray(d) ? d : []);
      setLoading(false);
    }).catch(() => setLoading(false));
  };

  useEffect(() => { fetchLeads(); }, []);

  const updateStatus = async (id: string, status: string) => {
    await fetch("/api/leads", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, status }),
    });
    fetchLeads();
    if (selectedLead?.id === id) setSelectedLead({ ...selectedLead!, status });
  };

  const filtered = leads.filter((l) => {
    if (!filter) return true;
    if (filter === "NEW") return l.status === "NEW";
    return JSON.stringify(l).toLowerCase().includes(filter.toLowerCase());
  });

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Leads</h1>
        <div className="flex gap-3">
          <select value={filter} onChange={(e) => setFilter(e.target.value)} className="input-field text-sm w-40">
            <option value="">All Leads</option>
            {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-2">
          {loading ? <p className="text-text-muted">Loading...</p> : filtered.map((lead) => (
            <button
              key={lead.id}
              onClick={() => setSelectedLead(lead)}
              className={`w-full text-left card-glass rounded-xl px-5 py-4 transition-all ${selectedLead?.id === lead.id ? "border-primary" : ""}`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-foreground">{lead.name}</p>
                  <p className="text-xs text-text-muted">{lead.email}</p>
                </div>
                <div className="text-right">
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    lead.status === "NEW" ? "bg-accent/20 text-accent" :
                    lead.status === "WON" ? "bg-green-500/20 text-green-400" :
                    lead.status === "LOST" ? "bg-red-500/20 text-red-400" :
                    "bg-surface-light text-text-muted"
                  }`}>{lead.status}</span>
                  <p className="text-xs text-text-muted mt-1">{new Date(lead.created_at).toLocaleDateString()}</p>
                </div>
              </div>
            </button>
          ))}
        </div>

        {selectedLead && (
          <div className="card-glass rounded-xl p-6 h-fit sticky top-24">
            <h2 className="font-bold text-foreground mb-4">{selectedLead.name}</h2>
            <div className="space-y-3 text-sm">
              <div><span className="text-text-muted">Email:</span> <span className="text-foreground">{selectedLead.email}</span></div>
              {selectedLead.phone && <div><span className="text-text-muted">Phone:</span> <span className="text-foreground">{selectedLead.phone}</span></div>}
              {selectedLead.company && <div><span className="text-text-muted">Company:</span> <span className="text-foreground">{selectedLead.company}</span></div>}
              {selectedLead.service && <div><span className="text-text-muted">Service:</span> <span className="text-foreground">{selectedLead.service}</span></div>}
              {selectedLead.source && <div><span className="text-text-muted">Source:</span> <span className="text-foreground">{selectedLead.source}</span></div>}
              {selectedLead.message && <div><span className="text-text-muted">Message:</span> <p className="text-foreground mt-1">{selectedLead.message}</p></div>}
            </div>
            <div className="mt-6 pt-4 border-t border-border">
              <p className="text-xs text-text-muted mb-2">Update Status</p>
              <div className="flex flex-wrap gap-2">
                {STATUSES.map((s) => (
                  <button
                    key={s}
                    onClick={() => updateStatus(selectedLead.id, s)}
                    className={`text-xs px-3 py-1.5 rounded-lg border transition-all ${
                      selectedLead.status === s
                        ? "bg-primary/20 border-primary text-primary-light"
                        : "border-border text-text-muted hover:border-primary"
                    }`}
                  >{s}</button>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

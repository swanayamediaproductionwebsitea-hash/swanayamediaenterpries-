import CMSList from "@/components/admin/CMSList";

const columns = [
  { key: "question", label: "Question" },
  { key: "answer", label: "Answer", textarea: true },
  { key: "category", label: "Category", type: "select", options: ["general", "services", "pricing", "process"] },
  { key: "sort_order", label: "Sort Order", type: "number" },
  { key: "published", label: "Published", boolean: true },
];

export default function AdminFAQsPage() {
  return <CMSList type="faqs" columns={columns} displayName="FAQs" />;
}

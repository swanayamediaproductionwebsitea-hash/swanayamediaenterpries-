"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

interface Analytics {
  overview: { totalEvents: number; uniqueSessions: number; activeSessions: number; leads: number };
  eventBreakdown: { event_type: string; count: number }[];
  topPages: { page: string; count: number }[];
  topServices: { service: string; count: number }[];
  deviceBreakdown: { device: string; count: number }[];
  sourceBreakdown: { source: string; count: number }[];
  conversions: { visitors: number; service_views: number; cta_clicks: number; contacts: number };
}

export default function AdminDashboard() {
  const [analytics, setAnalytics] = useState<Analytics | null>(null);
  const [leads, setLeads] = useState<{ id: string; name: string; email: string; status: string; created_at: string }[]>([]);
  const [period, setPeriod] = useState("7d");

  useEffect(() => {
    fetch(`/api/analytics?period=${period}`).then((r) => r.json()).then(setAnalytics).catch(() => {});
    fetch("/api/leads").then((r) => r.json()).then((d) => setLeads(Array.isArray(d) ? d : [])).catch(() => {});
  }, [period]);

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <select value={period} onChange={(e) => setPeriod(e.target.value)} className="input-field text-sm w-40">
          <option value="1d">Last 24 Hours</option>
          <option value="7d">Last 7 Days</option>
          <option value="30d">Last 30 Days</option>
          <option value="90d">Last 90 Days</option>
        </select>
      </div>

      {analytics && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {[
              { label: "Total Events", value: analytics.overview.totalEvents, color: "text-primary-light" },
              { label: "Unique Sessions", value: analytics.overview.uniqueSessions, color: "text-accent" },
              { label: "Active Sessions", value: analytics.overview.activeSessions, color: "text-gold" },
              { label: "Leads", value: analytics.overview.leads, color: "text-accent" },
            ].map((stat) => (
              <div key={stat.label} className="card-glass rounded-xl p-5">
                <p className="text-xs text-text-muted uppercase tracking-wider">{stat.label}</p>
                <p className={`text-3xl font-bold mt-1 ${stat.color}`}>{stat.value}</p>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Conversion Funnel */}
            <div className="card-glass rounded-xl p-6">
              <h2 className="font-bold text-foreground mb-4">Conversion Funnel</h2>
              {analytics.conversions && (
                <div className="space-y-3">
                  {[
                    { label: "Visitors", value: analytics.conversions.visitors || 0, width: "100%" },
                    { label: "Service Views", value: analytics.conversions.service_views || 0, width: "75%" },
                    { label: "CTA Clicks", value: analytics.conversions.cta_clicks || 0, width: "50%" },
                    { label: "Contacts", value: analytics.conversions.contacts || 0, width: "25%" },
                  ].map((step) => (
                    <div key={step.label}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-text-muted">{step.label}</span>
                        <span className="text-foreground font-medium">{step.value}</span>
                      </div>
                      <div className="h-2 bg-surface rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-primary to-accent rounded-full" style={{ width: step.width }} />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Top Pages */}
            <div className="card-glass rounded-xl p-6">
              <h2 className="font-bold text-foreground mb-4">Top Pages</h2>
              <div className="space-y-2">
                {analytics.topPages.slice(0, 8).map((p) => (
                  <div key={p.page} className="flex items-center justify-between text-sm">
                    <span className="text-text-muted truncate">{p.page}</span>
                    <span className="text-foreground font-medium flex-shrink-0 ml-2">{p.count}</span>
                  </div>
                ))}
                {analytics.topPages.length === 0 && <p className="text-text-muted text-sm">No data yet</p>}
              </div>
            </div>

            {/* Devices */}
            <div className="card-glass rounded-xl p-6">
              <h2 className="font-bold text-foreground mb-4">Devices</h2>
              <div className="space-y-3">
                {analytics.deviceBreakdown.map((d) => (
                  <div key={d.device} className="flex items-center justify-between">
                    <span className="text-sm text-text-muted capitalize">{d.device}</span>
                    <span className="text-sm font-medium text-foreground">{d.count}</span>
                  </div>
                ))}
                {analytics.deviceBreakdown.length === 0 && <p className="text-text-muted text-sm">No data yet</p>}
              </div>
            </div>

            {/* Sources */}
            <div className="card-glass rounded-xl p-6">
              <h2 className="font-bold text-foreground mb-4">Traffic Sources</h2>
              <div className="space-y-3">
                {analytics.sourceBreakdown.map((s) => (
                  <div key={s.source} className="flex items-center justify-between">
                    <span className="text-sm text-text-muted capitalize">{s.source}</span>
                    <span className="text-sm font-medium text-foreground">{s.count}</span>
                  </div>
                ))}
                {analytics.sourceBreakdown.length === 0 && <p className="text-text-muted text-sm">No data yet</p>}
              </div>
            </div>
          </div>

          {/* Event Types */}
          <div className="card-glass rounded-xl p-6 mb-8">
            <h2 className="font-bold text-foreground mb-4">Event Breakdown</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {analytics.eventBreakdown.map((e) => (
                <div key={e.event_type} className="text-center p-3 bg-surface rounded-lg">
                  <p className="text-lg font-bold text-foreground">{e.count}</p>
                  <p className="text-xs text-text-muted">{e.event_type.replace(/_/g, " ")}</p>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* Recent Leads */}
      <div className="card-glass rounded-xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-foreground">Recent Leads</h2>
          <Link href="/admin/leads" className="text-sm text-accent hover:underline">View All</Link>
        </div>
        <div className="space-y-2">
          {leads.slice(0, 5).map((lead) => (
            <div key={lead.id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
              <div>
                <p className="text-sm font-medium text-foreground">{lead.name}</p>
                <p className="text-xs text-text-muted">{lead.email}</p>
              </div>
              <div className="text-right">
                <span className={`text-xs px-2 py-0.5 rounded-full ${
                  lead.status === "NEW" ? "bg-accent/20 text-accent" :
                  lead.status === "WON" ? "bg-green-500/20 text-green-400" :
                  "bg-surface-light text-text-muted"
                }`}>
                  {lead.status}
                </span>
                <p className="text-xs text-text-muted mt-1">{new Date(lead.created_at).toLocaleDateString()}</p>
              </div>
            </div>
          ))}
          {leads.length === 0 && <p className="text-text-muted text-sm">No leads yet</p>}
        </div>
      </div>
    </div>
  );
}

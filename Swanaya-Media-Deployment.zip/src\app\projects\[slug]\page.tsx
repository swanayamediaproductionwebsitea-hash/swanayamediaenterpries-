import type { Metadata } from "next";
import { notFound } from "next/navigation";
import ScrollReveal from "@/components/ScrollReveal";
import Breadcrumbs from "@/components/Breadcrumbs";
import { getProjectBySlug, getProjects, getServices } from "@/lib/queries";
import { parseJsonArray } from "@/lib/utils";
import Link from "next/link";

export const dynamic = "force-dynamic";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const project = getProjectBySlug(slug) as Record<string, string> | undefined;
  if (!project) return {};
  return {
    title: project.seo_title || project.title,
    description: project.seo_description || project.short_description || "",
    openGraph: {
      title: project.og_title || project.title,
      description: project.og_description || project.short_description || "",
      images: project.og_image ? [project.og_image] : [],
    },
  };
}

export default async function ProjectDetailPage({ params }: Props) {
  const { slug } = await params;
  const project = getProjectBySlug(slug) as Record<string, string> | undefined;
  if (!project) notFound();

  const services = parseJsonArray<string>(project.services);
  const results = parseJsonArray<string>(project.results);
  const allServices = getServices() as { id: string; title: string; slug: string }[];

  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Projects", href: "/projects" }, { label: project.title }]} />

        <ScrollReveal>
          <div className="max-w-4xl py-12">
            {project.category && (
              <span className="text-xs bg-primary/20 text-primary-light px-3 py-1 rounded-full">{project.category}</span>
            )}
            <h1 className="text-4xl sm:text-5xl font-bold mt-4 mb-4">{project.title}</h1>
            {project.client && <p className="text-text-muted mb-4">Client: {project.client}</p>}
            {project.short_description && <p className="text-text-muted text-lg">{project.short_description}</p>}
          </div>
        </ScrollReveal>
      </div>

      <div className="h-64 lg:h-96 bg-gradient-to-br from-primary/20 to-accent/10 flex items-center justify-center">
        <div className="text-8xl opacity-20">✦</div>
      </div>

      {project.description && (
        <section className="py-16">
          <div className="max-w-4xl mx-auto px-4">
            <ScrollReveal>
              <div className="prose prose-invert max-w-none text-text-muted leading-relaxed" dangerouslySetInnerHTML={{ __html: project.description }} />
            </ScrollReveal>
          </div>
        </section>
      )}

      {results.length > 0 && (
        <section className="py-16 bg-surface">
          <div className="max-w-4xl mx-auto px-4">
            <ScrollReveal>
              <h2 className="text-3xl font-bold mb-8">Results</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {results.map((result, i) => (
                  <div key={i} className="card-glass rounded-xl p-5">
                    <p className="text-foreground text-sm">{result}</p>
                  </div>
                ))}
              </div>
            </ScrollReveal>
          </div>
        </section>
      )}

      <section className="py-24 bg-gradient-to-r from-primary/10 to-accent/10">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Want Similar Results?</h2>
          <p className="text-text-muted mb-8">Let&apos;s discuss your next project.</p>
          <Link href="/contact" className="btn-primary inline-block text-lg px-10 py-4">
            Start a Project
          </Link>
        </div>
      </section>
    </div>
  );
}

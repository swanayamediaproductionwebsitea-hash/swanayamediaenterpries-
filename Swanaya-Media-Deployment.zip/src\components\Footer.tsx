import Link from "next/link";

const footerLinks = {
  Services: [
    { href: "/services/digital-marketing", label: "Digital Marketing" },
    { href: "/services/web-development", label: "Web Development" },
    { href: "/services/branding", label: "Branding & Identity" },
    { href: "/services/video-production", label: "Video Production" },
    { href: "/services/social-media-management", label: "Social Media" },
    { href: "/services/consultancy", label: "Business Consultancy" },
  ],
  Company: [
    { href: "/about", label: "About Us" },
    { href: "/projects", label: "Our Projects" },
    { href: "/products", label: "Products" },
    { href: "/team", label: "Our Team" },
    { href: "/insights", label: "Insights" },
    { href: "/contact", label: "Contact" },
  ],
};

export default function Footer() {
  return (
    <footer className="bg-surface border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center font-bold text-white text-lg">
                S
              </div>
              <div>
                <span className="text-lg font-bold gradient-text">SWANAYA</span>
                <span className="block text-[10px] text-text-muted uppercase tracking-widest">Media Enterprises</span>
              </div>
            </Link>
            <p className="text-text-muted text-sm max-w-md mt-4 leading-relaxed">
              Creating Brands. Building Experiences. Growing Businesses. Swanaya Media Enterprises is a Kerala-based digital media company serving clients globally.
            </p>
            <div className="flex gap-4 mt-6">
              {["Instagram", "Facebook", "YouTube", "LinkedIn"].map((platform) => (
                <a
                  key={platform}
                  href="#"
                  className="w-10 h-10 rounded-lg bg-surface-light border border-border flex items-center justify-center text-text-muted hover:text-accent hover:border-accent transition-all duration-200"
                  aria-label={platform}
                >
                  {platform[0]}
                </a>
              ))}
            </div>
          </div>

          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h3 className="font-semibold text-foreground mb-4 text-sm uppercase tracking-wider">{title}</h3>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link.href}>
                    <Link href={link.href} className="text-text-muted hover:text-accent text-sm transition-colors duration-200">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div>
            <h3 className="font-semibold text-foreground mb-4 text-sm uppercase tracking-wider">Contact</h3>
            <ul className="space-y-3 text-sm text-text-muted">
              <li>
                <a href="mailto:swanayamediaproduction@gmail.com" className="hover:text-accent transition-colors">
                  swanayamediaproduction@gmail.com
                </a>
              </li>
              <li>Kerala, India</li>
              <li>Serving clients globally</li>
            </ul>
          </div>
        </div>

        <div className="border-t border-border mt-12 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-text-muted text-xs">
            &copy; {new Date().getFullYear()} Swanaya Media Enterprises. All rights reserved.
          </p>
          <div className="flex gap-6 text-xs text-text-muted">
            <Link href="/privacy" className="hover:text-accent transition-colors">Privacy Policy</Link>
            <Link href="/terms" className="hover:text-accent transition-colors">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

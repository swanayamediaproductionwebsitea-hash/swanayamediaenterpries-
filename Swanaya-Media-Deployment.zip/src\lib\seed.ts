import getDb from "./db";
import { generateId } from "./utils";

const db = getDb();

function seed() {
  console.log("Seeding Swanaya Media Enterprises database...");

  // Services
  const services = [
    { title: "Digital Marketing", slug: "digital-marketing", short_description: "Data-driven digital marketing strategies that drive growth, engagement and measurable results for your brand.", icon: "📈", features: JSON.stringify(["SEO & SEM", "Social Media Marketing", "Content Marketing", "Email Marketing", "PPC Campaigns", "Analytics & Reporting"]), process_steps: JSON.stringify(["Strategy & Research", "Campaign Design", "Execution & Launch", "Monitor & Optimize", "Report & Scale"]), aeo_question: "What is digital marketing at Swanaya Media Enterprises?", aeo_answer: "Swanaya Media Enterprises provides comprehensive digital marketing services including SEO, social media marketing, content marketing, email campaigns, PPC advertising and analytics-driven optimization to help businesses grow their online presence and generate measurable results." },
    { title: "Web Development", slug: "web-development", short_description: "Custom web applications, websites and platforms built with modern technology for performance, scalability and impact.", icon: "🌐", features: JSON.stringify(["Custom Website Development", "Web Applications", "E-Commerce Solutions", "CMS Development", "Progressive Web Apps", "API Development"]), process_steps: JSON.stringify(["Discovery & Planning", "UI/UX Design", "Development", "Testing & QA", "Launch & Support"]), aeo_question: "What web development services does Swanaya offer?", aeo_answer: "Swanaya Media Enterprises builds custom websites, web applications, e-commerce platforms, content management systems and progressive web apps using modern technologies optimized for performance, security and scalability." },
    { title: "Branding & Identity", slug: "branding", short_description: "Strategic brand development that creates memorable identities, visual systems and positioning that resonates with your audience.", icon: "✨", features: JSON.stringify(["Brand Strategy", "Logo Design", "Visual Identity Systems", "Brand Guidelines", "Brand Voice & Messaging", "Rebranding"]), process_steps: JSON.stringify(["Brand Research", "Strategy Development", "Visual Identity Design", "Guidelines Creation", "Brand Launch"]), aeo_question: "What branding services does Swanaya provide?", aeo_answer: "Swanaya Media Enterprises creates comprehensive brand identities including strategy, logo design, visual systems, brand guidelines, messaging frameworks and complete rebranding solutions that help businesses stand out." },
    { title: "Video Production", slug: "video-production", short_description: "Professional video production from concept to final delivery — corporate videos, commercials, explainer videos and cinematic content.", icon: "🎬", features: JSON.stringify(["Corporate Videos", "Commercial Production", "Explainer Videos", "Social Media Content", "Animation & Motion Graphics", "Post-Production"]), process_steps: JSON.stringify(["Concept & Scripting", "Pre-Production", "Production", "Post-Production", "Delivery & Distribution"]), aeo_question: "What video production services does Swanaya offer?", aeo_answer: "Swanaya Media Enterprises produces professional corporate videos, commercials, explainer videos, social media content and animated motion graphics from concept through post-production and delivery." },
    { title: "Social Media Management", slug: "social-media-management", short_description: "End-to-end social media management including content creation, scheduling, community management and growth strategies.", icon: "📱", features: JSON.stringify(["Content Strategy", "Content Creation", "Scheduling & Publishing", "Community Management", "Influencer Collaboration", "Performance Analytics"]), process_steps: JSON.stringify(["Audit & Strategy", "Content Calendar", "Creation & Design", "Publish & Engage", "Analyze & Optimize"]), aeo_question: "How does Swanaya manage social media?", aeo_answer: "Swanaya Media Enterprises handles complete social media management including strategy development, content creation, scheduling, community engagement, influencer partnerships and performance analytics across all major platforms." },
    { title: "Business Consultancy", slug: "consultancy", short_description: "Strategic business consultancy helping organizations identify opportunities, optimize operations and achieve sustainable growth.", icon: "💡", features: JSON.stringify(["Business Strategy", "Digital Transformation", "Market Research", "Operational Optimization", "Growth Planning", "Technology Advisory"]), process_steps: JSON.stringify(["Assessment & Analysis", "Strategy Development", "Implementation Planning", "Execution Support", "Performance Review"]), aeo_question: "What consultancy services does Swanaya provide?", aeo_answer: "Swanaya Media Enterprises offers business consultancy including strategic planning, digital transformation, market research, operational optimization, growth strategies and technology advisory services for organizations of all sizes." },
  ];

  const insertService = db.prepare(`
    INSERT OR IGNORE INTO services (id, title, slug, short_description, icon, features, process_steps, aeo_question, aeo_answer, sort_order, published)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
  `);

  services.forEach((s, i) => {
    insertService.run(generateId(), s.title, s.slug, s.short_description, s.icon, s.features, s.process_steps, s.aeo_question, s.aeo_answer, i);
  });

  // Team
  const teamMembers = [
    { name: "Swanaya Team", slug: "swanaya-team", role: "Creative Director", bio: "Leading creative vision and design excellence at Swanaya Media Enterprises." },
    { name: "Development Team", slug: "development-team", role: "Technical Lead", bio: "Building innovative digital solutions with cutting-edge technology." },
  ];

  const insertTeam = db.prepare(`
    INSERT OR IGNORE INTO team (id, name, slug, role, bio, published)
    VALUES (?, ?, ?, ?, ?, 1)
  `);

  teamMembers.forEach((t, i) => {
    insertTeam.run(generateId(), t.name, t.slug, t.role, t.bio);
  });

  // FAQs
  const faqs = [
    { question: "What does Swanaya Media Enterprises do?", answer: "Swanaya Media Enterprises provides digital media, marketing, branding, technology, web development and business-growth solutions for organizations, brands and entrepreneurs.", category: "general" },
    { question: "Where is Swanaya Media Enterprises based?", answer: "Swanaya Media Enterprises is based in Kerala, India and serves clients globally.", category: "general" },
    { question: "How can I contact Swanaya Media Enterprises?", answer: "You can reach us at swanayamediaproduction@gmail.com or through our contact form at swanayamedia.com/contact.", category: "general" },
    { question: "What industries does Swanaya serve?", answer: "Swanaya Media Enterprises serves a wide range of industries including technology, education, healthcare, retail, hospitality, real estate and more.", category: "general" },
    { question: "How long does a typical project take?", answer: "Project timelines vary based on scope. A website typically takes 4-8 weeks, while comprehensive branding or marketing campaigns may take 2-3 months.", category: "services" },
    { question: "Does Swanaya work with startups?", answer: "Yes, Swanaya Media Enterprises works with startups, SMEs and large enterprises, tailoring solutions to each organization's needs and goals.", category: "general" },
  ];

  const insertFaq = db.prepare(`
    INSERT OR IGNORE INTO faqs (id, question, answer, category, sort_order, published)
    VALUES (?, ?, ?, ?, ?, 1)
  `);

  faqs.forEach((f, i) => {
    insertFaq.run(generateId(), f.question, f.answer, f.category, i);
  });

  // Social links
  const socials = [
    { platform: "instagram", url: "https://instagram.com/swanayamedia", title: "Instagram" },
    { platform: "facebook", url: "https://facebook.com/swanayamedia", title: "Facebook" },
    { platform: "youtube", url: "https://youtube.com/@swanayamedia", title: "YouTube" },
    { platform: "linkedin", url: "https://linkedin.com/company/swanayamedia", title: "LinkedIn" },
  ];

  const insertSocial = db.prepare(`
    INSERT OR IGNORE INTO social_links (id, platform, url, title, published)
    VALUES (?, ?, ?, ?, 1)
  `);

  socials.forEach((s, i) => {
    insertSocial.run(generateId(), s.platform, s.url, s.title);
  });

  // Sample blog post
  const blogId = generateId();
  db.prepare(`
    INSERT OR IGNORE INTO blog (id, title, slug, excerpt, content, category, tags, published, featured, read_time, aeo_question, aeo_answer, published_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, 1, 1, 5, ?, ?, datetime('now'))
  `).run(
    blogId,
    "How Digital Marketing Helps Businesses Grow",
    "how-digital-marketing-helps-businesses-grow",
    "Discover how strategic digital marketing can transform your business visibility, engagement and revenue.",
    `<h2>What is Digital Marketing?</h2><p>Digital marketing encompasses all marketing efforts that use electronic devices or the internet. Businesses leverage digital channels such as search engines, social media, email and websites to connect with current and prospective customers.</p><h2>Why Digital Marketing Matters</h2><p>In today's connected world, digital marketing is essential for business growth. It allows brands to reach wider audiences, engage with customers in real-time and measure results with precision.</p><h2>Key Digital Marketing Strategies</h2><ul><li><strong>Search Engine Optimization (SEO)</strong> — Improving your website's visibility in organic search results</li><li><strong>Social Media Marketing</strong> — Building brand awareness and community through social platforms</li><li><strong>Content Marketing</strong> — Creating valuable content that attracts and retains your target audience</li><li><strong>Email Marketing</strong> — Direct communication with your audience for conversions and retention</li><li><strong>PPC Advertising</strong> - Targeted paid campaigns for immediate visibility</li></ul><h2>How Swanaya Can Help</h2><p>At Swanaya Media Enterprises, we create tailored digital marketing strategies that combine these channels for maximum impact. Our data-driven approach ensures every campaign delivers measurable results.</p>`,
    "Digital Marketing",
    "digital marketing,business growth,SEO,social media",
    "How does digital marketing help businesses?",
    "Digital marketing helps businesses increase visibility, reach targeted audiences, build brand awareness, generate leads and drive measurable revenue growth through channels like SEO, social media, content marketing and paid advertising."
  );

  console.log("Seeding complete!");
  console.log(`  - ${services.length} services`);
  console.log(`  - ${teamMembers.length} team members`);
  console.log(`  - ${faqs.length} FAQs`);
  console.log(`  - ${socials.length} social links`);
  console.log(`  - 1 sample blog post`);
}

seed();

import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { getSettings } from "@/lib/queries";

export const dynamic = "force-dynamic";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export function generateMetadata(): Metadata {
  const settings = getSettings();
  return {
    title: {
      default: `${settings.company_name || "Swanaya Media Enterprises"} — ${settings.tagline || "Creating Brands. Building Experiences. Growing Businesses."}`,
      template: `%s | ${settings.company_name || "Swanaya Media Enterprises"}`,
    },
    description: settings.description || "Swanaya Media Enterprises provides digital media, marketing, branding, technology, web development and business-growth solutions.",
    metadataBase: new URL(settings.website || "https://swanayamedia.com"),
    openGraph: {
      type: "website",
      locale: "en_US",
      siteName: settings.company_name || "Swanaya Media Enterprises",
      title: settings.company_name || "Swanaya Media Enterprises",
      description: settings.description || "",
    },
    twitter: {
      card: "summary_large_image",
    },
    robots: { index: true, follow: true },
  };
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const settings = getSettings();

  const orgSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: settings.company_name || "Swanaya Media Enterprises",
    url: settings.website || "https://swanayamedia.com",
    email: settings.email || "swanayamediaproduction@gmail.com",
    description: settings.description || "",
    address: {
      "@type": "PostalAddress",
      addressRegion: "Kerala",
      addressCountry: "IN",
    },
    sameAs: [],
  };

  const websiteSchema = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: settings.company_name || "Swanaya Media Enterprises",
    url: settings.website || "https://swanayamedia.com",
    potentialAction: {
      "@type": "SearchAction",
      target: `${settings.website || "https://swanayamedia.com"}/search?q={search_term_string}`,
      "query-input": "required name=search_term_string",
    },
  };

  return (
    <html lang="en" className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}>
      <head>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(orgSchema) }} />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }} />
      </head>
      <body className="min-h-full flex flex-col bg-background text-foreground">
        <Navbar />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}

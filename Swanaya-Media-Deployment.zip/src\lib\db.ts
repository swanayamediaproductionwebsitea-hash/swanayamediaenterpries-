import Database from "better-sqlite3";
import path from "path";

const DB_PATH = path.join(process.cwd(), "swanaya.db");

let db: Database.Database;

function getDb(): Database.Database {
  if (!db) {
    try {
      db = new Database(DB_PATH, { timeout: 10000 });
      db.pragma("journal_mode = WAL");
      db.pragma("busy_timeout = 10000");
      db.pragma("synchronous = NORMAL");
      db.pragma("foreign_keys = ON");
      initializeDatabase(db);
    } catch (e) {
      if (db) { try { db.close(); } catch {} }
      throw e;
    }
  }
  return db;
}

function initializeDatabase(database: Database.Database) {
  database.exec(`
    CREATE TABLE IF NOT EXISTS services (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      short_description TEXT,
      description TEXT,
      icon TEXT,
      features TEXT,
      process_steps TEXT,
      faqs TEXT,
      image TEXT,
      sort_order INTEGER DEFAULT 0,
      published INTEGER DEFAULT 1,
      seo_title TEXT,
      seo_description TEXT,
      seo_canonical TEXT,
      og_title TEXT,
      og_description TEXT,
      og_image TEXT,
      indexable INTEGER DEFAULT 1,
      aeo_question TEXT,
      aeo_answer TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      short_description TEXT,
      description TEXT,
      client TEXT,
      category TEXT,
      services TEXT,
      thumbnail TEXT,
      gallery TEXT,
      results TEXT,
      featured INTEGER DEFAULT 0,
      published INTEGER DEFAULT 1,
      seo_title TEXT,
      seo_description TEXT,
      seo_canonical TEXT,
      og_title TEXT,
      og_description TEXT,
      og_image TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      short_description TEXT,
      description TEXT,
      category TEXT,
      features TEXT,
      pricing TEXT,
      image TEXT,
      gallery TEXT,
      demo_url TEXT,
      published INTEGER DEFAULT 1,
      seo_title TEXT,
      seo_description TEXT,
      seo_canonical TEXT,
      og_title TEXT,
      og_description TEXT,
      og_image TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS team (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      role TEXT,
      bio TEXT,
      avatar TEXT,
      email TEXT,
      linkedin TEXT,
      twitter TEXT,
      sort_order INTEGER DEFAULT 0,
      published INTEGER DEFAULT 1,
      seo_title TEXT,
      seo_description TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS blog (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      excerpt TEXT,
      content TEXT,
      author_id TEXT,
      category TEXT,
      tags TEXT,
      featured_image TEXT,
      published INTEGER DEFAULT 0,
      featured INTEGER DEFAULT 0,
      read_time INTEGER DEFAULT 5,
      seo_title TEXT,
      seo_description TEXT,
      seo_canonical TEXT,
      og_title TEXT,
      og_description TEXT,
      og_image TEXT,
      aeo_question TEXT,
      aeo_answer TEXT,
      published_at TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now')),
      FOREIGN KEY (author_id) REFERENCES team(id)
    );

    CREATE TABLE IF NOT EXISTS leads (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT,
      company TEXT,
      service TEXT,
      message TEXT,
      source TEXT,
      campaign TEXT,
      status TEXT DEFAULT 'NEW',
      notes TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS analytics_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event_type TEXT NOT NULL,
      page TEXT,
      service TEXT,
      project TEXT,
      product TEXT,
      blog TEXT,
      search_query TEXT,
      source TEXT,
      medium TEXT,
      campaign TEXT,
      device TEXT,
      region TEXT,
      session_id TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS analytics_sessions (
      id TEXT PRIMARY KEY,
      started_at TEXT DEFAULT (datetime('now')),
      last_active TEXT DEFAULT (datetime('now')),
      page_views INTEGER DEFAULT 0,
      device TEXT,
      region TEXT,
      source TEXT,
      medium TEXT,
      campaign TEXT
    );

    CREATE TABLE IF NOT EXISTS social_links (
      id TEXT PRIMARY KEY,
      platform TEXT NOT NULL,
      url TEXT NOT NULL,
      title TEXT,
      description TEXT,
      icon TEXT,
      sort_order INTEGER DEFAULT 0,
      published INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS social_posts (
      id TEXT PRIMARY KEY,
      platform TEXT NOT NULL,
      title TEXT,
      description TEXT,
      thumbnail TEXT,
      url TEXT,
      category TEXT,
      published_at TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT,
      updated_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS faqs (
      id TEXT PRIMARY KEY,
      question TEXT NOT NULL,
      answer TEXT NOT NULL,
      category TEXT,
      sort_order INTEGER DEFAULT 0,
      published INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS media (
      id TEXT PRIMARY KEY,
      filename TEXT NOT NULL,
      original_name TEXT,
      mime_type TEXT,
      size INTEGER,
      url TEXT NOT NULL,
      alt TEXT,
      caption TEXT,
      folder TEXT,
      created_at TEXT DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS pages (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      content TEXT,
      template TEXT DEFAULT 'default',
      published INTEGER DEFAULT 1,
      seo_title TEXT,
      seo_description TEXT,
      seo_canonical TEXT,
      og_title TEXT,
      og_description TEXT,
      og_image TEXT,
      indexable INTEGER DEFAULT 1,
      created_at TEXT DEFAULT (datetime('now')),
      updated_at TEXT DEFAULT (datetime('now'))
    );
  `);

  const settingsCount = database.prepare("SELECT COUNT(*) as count FROM settings").get() as { count: number };
  if (settingsCount.count === 0) {
    const insertSettings = database.prepare("INSERT INTO settings (key, value) VALUES (?, ?)");
    const defaultSettings = [
      ["company_name", "Swanaya Media Enterprises"],
      ["tagline", "Creating Brands. Building Experiences. Growing Businesses."],
      ["email", "swanayamediaproduction@gmail.com"],
      ["phone", ""],
      ["address", "Kerala, India"],
      ["website", "https://swanayamedia.com"],
      ["description", "Swanaya Media Enterprises provides digital media, marketing, branding, technology, web development and business-growth solutions for organizations, brands and entrepreneurs."],
      ["admin_password", "swanaya2026"],
      ["analytics_enabled", "true"],
    ];
    const insertMany = database.transaction(() => {
      for (const [key, value] of defaultSettings) {
        insertSettings.run(key, value);
      }
    });
    insertMany();
  }
}

export default getDb;

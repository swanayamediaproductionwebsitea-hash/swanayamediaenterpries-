import Hero3D from "@/components/Hero3D";
import ServiceCard from "@/components/ServiceCard";
import ProjectCard from "@/components/ProjectCard";
import BlogCard from "@/components/BlogCard";
import ScrollReveal from "@/components/ScrollReveal";
import FAQSection from "@/components/FAQSection";
import { getServices, getProjects, getBlogPosts, getFaqs, getSettings } from "@/lib/queries";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default function HomePage() {
  const services = getServices() as { id: string; title: string; slug: string; short_description: string; icon: string; features: string }[];
  const projects = getProjects() as { id: string; title: string; slug: string; short_description: string; client: string; category: string }[];
  const blogs = getBlogPosts() as { id: string; title: string; slug: string; excerpt: string; category: string; published_at: string; read_time: number; author_name: string }[];
  const faqs = getFaqs() as { question: string; answer: string }[];
  const settings = getSettings();

  return (
    <>
      <Hero3D />

      {/* Services Section */}
      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-16">
              <span className="text-accent text-sm font-semibold uppercase tracking-wider">Our Services</span>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mt-2 mb-4">
                Comprehensive <span className="gradient-text">Digital Solutions</span>
              </h2>
              <p className="text-text-muted max-w-2xl mx-auto">
                From strategy to execution, we provide end-to-end digital solutions that drive measurable business growth.
              </p>
            </div>
          </ScrollReveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {services.map((service, i) => (
              <ScrollReveal key={service.id} delay={i * 100}>
                <ServiceCard
                  title={service.title}
                  description={service.short_description || ""}
                  icon={service.icon}
                  href={`/services/${service.slug}`}
                  features={service.features ? JSON.parse(service.features) : []}
                />
              </ScrollReveal>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link href="/services" className="btn-primary inline-block">
              View All Services
            </Link>
          </div>
        </div>
      </section>

      {/* About Preview */}
      <section className="py-24 bg-surface">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <ScrollReveal>
              <span className="text-accent text-sm font-semibold uppercase tracking-wider">About Swanaya</span>
              <h2 className="text-3xl sm:text-4xl font-bold mt-2 mb-6">
                A Digital Headquarters for <span className="gradient-text">Modern Brands</span>
              </h2>
              <p className="text-text-muted leading-relaxed mb-6">
                Swanaya Media Enterprises is a Kerala-based digital media company that combines creative strategy with technology to build brands, create experiences and drive business growth.
              </p>
              <p className="text-text-muted leading-relaxed mb-8">
                We serve startups, SMEs and enterprises with comprehensive solutions spanning digital marketing, web development, branding, video production, social media management and business consultancy.
              </p>
              <div className="grid grid-cols-3 gap-6">
                {[
                  { label: "Services", value: services.length + "+" },
                  { label: "Projects", value: projects.length + "+" },
                  { label: "Clients", value: "Global" },
                ].map((stat) => (
                  <div key={stat.label}>
                    <div className="text-2xl font-bold gradient-text">{stat.value}</div>
                    <div className="text-xs text-text-muted mt-1">{stat.label}</div>
                  </div>
                ))}
              </div>
            </ScrollReveal>
            <ScrollReveal delay={200}>
              <div className="card-glass rounded-2xl p-8 relative">
                <div className="absolute -top-4 -right-4 w-24 h-24 bg-primary/20 rounded-full blur-2xl" />
                <h3 className="text-xl font-bold text-foreground mb-6">Why Choose Swanaya?</h3>
                <ul className="space-y-4">
                  {[
                    "Premium creative and technical expertise",
                    "Data-driven strategies with measurable results",
                    "End-to-end solutions under one roof",
                    "Kerala-based with global perspective",
                    "Transparent communication and collaboration",
                    "Scalable solutions that grow with your business",
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <span className="w-5 h-5 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <span className="text-accent text-xs">✓</span>
                      </span>
                      <span className="text-sm text-text-muted">{item}</span>
                    </li>
                  ))}
                </ul>
                <Link href="/about" className="btn-accent inline-block mt-8 text-sm">
                  Learn More About Us
                </Link>
              </div>
            </ScrollReveal>
          </div>
        </div>
      </section>

      {/* Featured Projects */}
      {projects.length > 0 && (
        <section className="py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ScrollReveal>
              <div className="text-center mb-16">
                <span className="text-accent text-sm font-semibold uppercase tracking-wider">Featured Projects</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mt-2 mb-4">
                  Our <span className="gradient-text">Work</span>
                </h2>
              </div>
            </ScrollReveal>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.slice(0, 3).map((project, i) => (
                <ScrollReveal key={project.id} delay={i * 100}>
                  <ProjectCard {...project} />
                </ScrollReveal>
              ))}
            </div>
            <div className="text-center mt-12">
              <Link href="/projects" className="btn-primary inline-block">
                View All Projects
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* Blog Preview */}
      {blogs.length > 0 && (
        <section className="py-24 bg-surface">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ScrollReveal>
              <div className="text-center mb-16">
                <span className="text-accent text-sm font-semibold uppercase tracking-wider">Latest Insights</span>
                <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mt-2 mb-4">
                  From Our <span className="gradient-text">Blog</span>
                </h2>
              </div>
            </ScrollReveal>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {blogs.slice(0, 3).map((blog, i) => (
                <ScrollReveal key={blog.id} delay={i * 100}>
                  <BlogCard {...blog} />
                </ScrollReveal>
              ))}
            </div>
            <div className="text-center mt-12">
              <Link href="/insights" className="btn-primary inline-block">
                Read More Insights
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-24 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-accent/10" />
        <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
          <ScrollReveal>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold mb-6">
              Ready to <span className="gradient-text">Grow Your Business</span>?
            </h2>
            <p className="text-text-muted text-lg mb-8 max-w-2xl mx-auto">
              Let Swanaya Media Enterprises help you create a powerful digital presence that drives real results.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/contact" className="btn-primary text-lg px-10 py-4">
                Start a Project
              </Link>
              <Link href="/services" className="btn-accent text-lg px-10 py-4">
                Explore Services
              </Link>
            </div>
          </ScrollReveal>
        </div>
      </section>

      {/* FAQ */}
      <FAQSection faqs={faqs} />
    </>
  );
}

import type { Metadata } from "next";
import ScrollReveal from "@/components/ScrollReveal";
import TeamCard from "@/components/TeamCard";
import Breadcrumbs from "@/components/Breadcrumbs";
import { getTeam } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Team",
  description: "Meet the team behind Swanaya Media Enterprises — creative and technical professionals building digital experiences.",
};

export default function TeamPage() {
  const team = getTeam() as { id: string; name: string; slug: string; role: string; bio: string; avatar: string }[];

  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Team" }]} />
        <ScrollReveal>
          <div className="max-w-4xl py-12">
            <span className="text-accent text-sm font-semibold uppercase tracking-wider">Our Team</span>
            <h1 className="text-4xl sm:text-5xl font-bold mt-2 mb-6">
              The People Behind <span className="gradient-text">Swanaya</span>
            </h1>
            <p className="text-text-muted text-lg">
              A talented team of creative and technical professionals dedicated to building exceptional digital experiences.
            </p>
          </div>
        </ScrollReveal>
      </div>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {team.map((member, i) => (
              <ScrollReveal key={member.id} delay={i * 100}>
                <TeamCard {...member} />
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

import CMSList from "@/components/admin/CMSList";

const columns = [
  { key: "title", label: "Title" },
  { key: "slug", label: "Slug" },
  { key: "excerpt", label: "Excerpt", textarea: true },
  { key: "content", label: "Content (HTML)", textarea: true },
  { key: "category", label: "Category" },
  { key: "tags", label: "Tags (comma-separated)" },
  { key: "featured", label: "Featured", boolean: true },
  { key: "published", label: "Published", boolean: true },
  { key: "aeo_question", label: "AEO Question", textarea: true },
  { key: "aeo_answer", label: "AEO Answer", textarea: true },
  { key: "seo_title", label: "SEO Title" },
  { key: "seo_description", label: "SEO Description", textarea: true },
  { key: "og_title", label: "OG Title" },
  { key: "og_description", label: "OG Description", textarea: true },
  { key: "og_image", label: "OG Image URL" },
];

export default function AdminBlogPage() {
  return <CMSList type="blog" columns={columns} displayName="Blog Posts" />;
}

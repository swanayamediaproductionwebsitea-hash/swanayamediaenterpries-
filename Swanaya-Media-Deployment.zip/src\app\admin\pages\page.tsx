import CMSList from "@/components/admin/CMSList";

const columns = [
  { key: "title", label: "Title" },
  { key: "slug", label: "Slug" },
  { key: "content", label: "Content (HTML)", textarea: true },
  { key: "template", label: "Template", type: "select", options: ["default", "full-width", "sidebar", "landing"] },
  { key: "published", label: "Published", boolean: true },
  { key: "seo_title", label: "SEO Title" },
  { key: "seo_description", label: "SEO Description", textarea: true },
  { key: "indexable", label: "Indexable", boolean: true },
];

export default function AdminPagesPage() {
  return <CMSList type="pages" columns={columns} displayName="Pages" />;
}

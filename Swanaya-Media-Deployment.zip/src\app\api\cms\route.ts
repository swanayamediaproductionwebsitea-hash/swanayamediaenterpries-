import { NextRequest } from "next/server";
import getDb from "@/lib/db";
import { generateId, slugify } from "@/lib/utils";

const TABLES: Record<string, { table: string; slugField?: boolean }> = {
  services: { table: "services", slugField: true },
  projects: { table: "projects", slugField: true },
  products: { table: "products", slugField: true },
  team: { table: "team", slugField: true },
  blog: { table: "blog", slugField: true },
  pages: { table: "pages", slugField: true },
  social_links: { table: "social_links" },
  social_posts: { table: "social_posts" },
  faqs: { table: "faqs" },
  media: { table: "media" },
  settings: { table: "settings" },
};

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get("type") || "services";
  const config = TABLES[type];
  if (!config) return Response.json({ error: "Invalid type" }, { status: 400 });

  const db = getDb();

  if (type === "settings") {
    const rows = db.prepare("SELECT * FROM settings").all() as { key: string; value: string }[];
    const settings: Record<string, string> = {};
    for (const row of rows) settings[row.key] = row.value;
    return Response.json(settings);
  }

  const rows = db.prepare(`SELECT * FROM ${config.table} ORDER BY created_at DESC`).all();
  return Response.json(rows);
}

export async function POST(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get("type") || "services";
  const config = TABLES[type];
  if (!config) return Response.json({ error: "Invalid type" }, { status: 400 });

  const db = getDb();
  const body = await request.json();
  const id = generateId();

  if (type === "settings") {
    const upsert = db.prepare("INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, datetime('now'))");
    const updateMany = db.transaction(() => {
      for (const [key, value] of Object.entries(body)) {
        upsert.run(key, String(value));
      }
    });
    updateMany();
    return Response.json({ success: true });
  }

  if (config.slugField && body.title && !body.slug) {
    body.slug = slugify(body.title);
  }

  const columns = ["id", ...Object.keys(body)];
  const placeholders = columns.map(() => "?").join(", ");
  const values = [id, ...Object.values(body)];

  db.prepare(`INSERT INTO ${config.table} (${columns.join(", ")}) VALUES (${placeholders})`).run(...values);
  return Response.json({ success: true, id });
}

export async function PUT(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get("type") || "services";
  const config = TABLES[type];
  if (!config) return Response.json({ error: "Invalid type" }, { status: 400 });

  const db = getDb();
  const body = await request.json();
  const { id, ...updates } = body;
  if (!id) return Response.json({ error: "id required" }, { status: 400 });

  if (type === "settings") {
    const upsert = db.prepare("INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, datetime('now'))");
    const updateMany = db.transaction(() => {
      for (const [key, value] of Object.entries(updates)) {
        upsert.run(key, String(value));
      }
    });
    updateMany();
    return Response.json({ success: true });
  }

  const setClauses = Object.keys(updates).map((k) => `${k} = ?`);
  const setValues = Object.values(updates);

  db.prepare(`UPDATE ${config.table} SET ${setClauses.join(", ")}, updated_at = datetime('now') WHERE id = ?`).run(
    ...setValues,
    id
  );
  return Response.json({ success: true });
}

export async function DELETE(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get("type") || "services";
  const config = TABLES[type];
  if (!config) return Response.json({ error: "Invalid type" }, { status: 400 });

  const db = getDb();
  const { searchParams: reqParams } = new URL(request.url);
  const id = reqParams.get("id");
  if (!id) return Response.json({ error: "id required" }, { status: 400 });

  db.prepare(`DELETE FROM ${config.table} WHERE id = ?`).run(id);
  return Response.json({ success: true });
}

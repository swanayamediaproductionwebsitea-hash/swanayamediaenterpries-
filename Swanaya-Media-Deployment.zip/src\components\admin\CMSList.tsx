"use client";

import { useState, useEffect, useCallback } from "react";

interface CMSItem {
  id: string;
  [key: string]: unknown;
}

interface Props {
  type: string;
  columns: { key: string; label: string; type?: string; options?: string[]; json?: boolean; textarea?: boolean; boolean?: boolean; seo?: boolean; aeo?: boolean }[];
  displayName?: string;
}

export default function CMSList({ type, columns, displayName }: Props) {
  const [items, setItems] = useState<CMSItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<CMSItem | null>(null);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState<Record<string, string>>({});
  const [filter, setFilter] = useState("");
  const [message, setMessage] = useState("");

  const fetchItems = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/cms?type=${type}`);
      const data = await res.json();
      setItems(Array.isArray(data) ? data : []);
    } catch { setItems([]); }
    setLoading(false);
  }, [type]);

  useEffect(() => { fetchItems(); }, [fetchItems]);

  const handleSave = async () => {
    const method = editing ? "PUT" : "POST";
    const body = editing ? { ...form, id: editing.id } : form;

    try {
      const res = await fetch(`/api/cms?type=${type}`, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (res.ok) {
        setMessage(editing ? "Updated successfully" : "Created successfully");
        setEditing(null);
        setCreating(false);
        setForm({});
        fetchItems();
      } else {
        setMessage("Error saving");
      }
    } catch { setMessage("Error saving"); }
    setTimeout(() => setMessage(""), 3000);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this item?")) return;
    try {
      await fetch(`/api/cms?type=${type}&id=${id}`, { method: "DELETE" });
      setMessage("Deleted");
      fetchItems();
    } catch { setMessage("Error deleting"); }
    setTimeout(() => setMessage(""), 3000);
  };

  const startEdit = (item: CMSItem) => {
    setEditing(item);
    setCreating(false);
    const f: Record<string, string> = {};
    for (const col of columns) {
      const val = item[col.key];
      if (col.json && Array.isArray(val)) f[col.key] = JSON.stringify(val, null, 2);
      else if (col.boolean) f[col.key] = val ? "1" : "0";
      else f[col.key] = String(val ?? "");
    }
    setForm(f);
  };

  const startCreate = () => {
    setCreating(true);
    setEditing(null);
    const f: Record<string, string> = {};
    for (const col of columns) {
      if (col.boolean) f[col.key] = "0";
      else f[col.key] = "";
    }
    setForm(f);
  };

  const filteredItems = items.filter((item) => {
    if (!filter) return true;
    const searchStr = JSON.stringify(item).toLowerCase();
    return searchStr.includes(filter.toLowerCase());
  });

  const renderForm = () => (
    <div className="card-glass rounded-xl p-6 mb-6">
      <h3 className="font-bold text-foreground mb-4">{editing ? `Edit ${displayName || type}` : `Create ${displayName || type}`}</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {columns.map((col) => (
          <div key={col.key} className={col.textarea || col.seo || col.aeo ? "md:col-span-2" : ""}>
            <label className="block text-xs font-medium text-text-muted mb-1">{col.label}</label>
            {col.type === "select" && col.options ? (
              <select value={form[col.key] || ""} onChange={(e) => setForm({ ...form, [col.key]: e.target.value })} className="input-field text-sm">
                <option value="">Select...</option>
                {col.options.map((o) => <option key={o} value={o}>{o}</option>)}
              </select>
            ) : col.textarea || col.seo || col.aeo ? (
              <textarea value={form[col.key] || ""} onChange={(e) => setForm({ ...form, [col.key]: e.target.value })} rows={4} className="input-field text-sm resize-y" />
            ) : col.boolean ? (
              <select value={form[col.key] || "0"} onChange={(e) => setForm({ ...form, [col.key]: e.target.value })} className="input-field text-sm">
                <option value="1">Yes</option>
                <option value="0">No</option>
              </select>
            ) : (
              <input type={col.type || "text"} value={form[col.key] || ""} onChange={(e) => setForm({ ...form, [col.key]: e.target.value })} className="input-field text-sm" />
            )}
          </div>
        ))}
      </div>
      <div className="flex gap-3 mt-4">
        <button onClick={handleSave} className="btn-primary text-sm py-2 px-5">Save</button>
        <button onClick={() => { setEditing(null); setCreating(false); setForm({}); }} className="text-sm text-text-muted hover:text-foreground px-4 py-2">Cancel</button>
      </div>
    </div>
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">{displayName || type.charAt(0).toUpperCase() + type.slice(1)}</h1>
        <div className="flex gap-3">
          <input type="text" placeholder="Filter..." value={filter} onChange={(e) => setFilter(e.target.value)} className="input-field text-sm w-48" />
          <button onClick={startCreate} className="btn-accent text-sm py-2 px-4">+ New</button>
        </div>
      </div>

      {message && <div className="bg-accent/10 text-accent text-sm px-4 py-2 rounded-lg mb-4">{message}</div>}

      {(creating || editing) && renderForm()}

      {loading ? (
        <p className="text-text-muted">Loading...</p>
      ) : filteredItems.length === 0 ? (
        <p className="text-text-muted text-center py-12">No items found. Create your first {displayName || type}.</p>
      ) : (
        <div className="space-y-2">
          {filteredItems.map((item) => (
            <div key={item.id} className="card-glass rounded-xl px-5 py-3 flex items-center justify-between gap-4">
              <div className="flex-1 min-w-0">
                <p className="font-medium text-foreground text-sm truncate">
                  {String(item.title || item.name || item.question || item.key || item.id)}
                </p>
                <p className="text-xs text-text-muted truncate">
                  {String(item.slug || item.platform || item.email || item.short_description || "").substring(0, 100)}
                </p>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <button onClick={() => startEdit(item)} className="text-xs text-primary-light hover:text-primary px-2 py-1">Edit</button>
                <button onClick={() => handleDelete(item.id)} className="text-xs text-red-400 hover:text-red-300 px-2 py-1">Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

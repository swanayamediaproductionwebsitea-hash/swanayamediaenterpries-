interface Props {
  name: string;
  role?: string;
  avatar?: string;
  bio?: string;
  linkedin?: string;
  twitter?: string;
}

export default function TeamCard({ name, role, bio }: Props) {
  return (
    <div className="card-glass rounded-2xl p-6 text-center hover:border-primary/50 transition-all duration-300 hover:-translate-y-1">
      <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-accent mx-auto mb-4 flex items-center justify-center text-2xl font-bold text-white">
        {name.charAt(0)}
      </div>
      <h3 className="text-lg font-bold text-foreground">{name}</h3>
      {role && <p className="text-sm text-accent mt-1">{role}</p>}
      {bio && <p className="text-sm text-text-muted mt-3 leading-relaxed">{bio}</p>}
    </div>
  );
}

import type { Metadata } from "next";
import ScrollReveal from "@/components/ScrollReveal";
import BlogCard from "@/components/BlogCard";
import Breadcrumbs from "@/components/Breadcrumbs";
import { getBlogPosts } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Insights",
  description: "Insights, articles and resources from Swanaya Media Enterprises on digital marketing, branding, web development and business growth.",
};

export default function InsightsPage() {
  const blogs = getBlogPosts() as { id: string; title: string; slug: string; excerpt: string; category: string; published_at: string; read_time: number; author_name: string }[];

  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Insights" }]} />
        <ScrollReveal>
          <div className="max-w-4xl py-12">
            <span className="text-accent text-sm font-semibold uppercase tracking-wider">Insights</span>
            <h1 className="text-4xl sm:text-5xl font-bold mt-2 mb-6">
              Our <span className="gradient-text">Blog</span>
            </h1>
            <p className="text-text-muted text-lg">
              Expert insights, industry trends and practical guides on digital marketing, branding and business growth.
            </p>
          </div>
        </ScrollReveal>
      </div>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {blogs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {blogs.map((blog, i) => (
                <ScrollReveal key={blog.id} delay={i * 100}>
                  <BlogCard {...blog} />
                </ScrollReveal>
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <p className="text-text-muted text-lg">Blog posts coming soon. Check back later.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

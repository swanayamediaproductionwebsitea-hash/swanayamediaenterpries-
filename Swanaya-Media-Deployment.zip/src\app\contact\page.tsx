import type { Metadata } from "next";
import ScrollReveal from "@/components/ScrollReveal";
import ContactForm from "@/components/ContactForm";
import Breadcrumbs from "@/components/Breadcrumbs";
import { getServices, getSettings, getSocialLinks } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Contact",
  description: "Get in touch with Swanaya Media Enterprises. Start your next project or discuss how we can help grow your business.",
};

export default function ContactPage() {
  const services = getServices() as { title: string }[];
  const settings = getSettings();
  const socials = getSocialLinks() as { platform: string; url: string }[];

  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Contact" }]} />

        <ScrollReveal>
          <div className="max-w-4xl py-12">
            <span className="text-accent text-sm font-semibold uppercase tracking-wider">Contact Us</span>
            <h1 className="text-4xl sm:text-5xl font-bold mt-2 mb-6">
              Let&apos;s Build Something <span className="gradient-text">Great Together</span>
            </h1>
            <p className="text-text-muted text-lg">
              Have a project in mind? Fill out the form below and we will get back to you within 24 hours.
            </p>
          </div>
        </ScrollReveal>
      </div>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2">
              <ContactForm services={services.map((s) => s.title)} />
            </div>
            <div className="space-y-8">
              <ScrollReveal>
                <div className="card-glass rounded-2xl p-6">
                  <h3 className="font-bold text-foreground mb-4">Get in Touch</h3>
                  <div className="space-y-4 text-sm">
                    <div>
                      <p className="text-text-muted">Email</p>
                      <a href={`mailto:${settings.email}`} className="text-accent hover:underline">{settings.email}</a>
                    </div>
                    {settings.phone && (
                      <div>
                        <p className="text-text-muted">Phone</p>
                        <a href={`tel:${settings.phone}`} className="text-accent hover:underline">{settings.phone}</a>
                      </div>
                    )}
                    <div>
                      <p className="text-text-muted">Location</p>
                      <p className="text-foreground">{settings.address || "Kerala, India"}</p>
                    </div>
                  </div>
                </div>
              </ScrollReveal>

              <ScrollReveal delay={100}>
                <div className="card-glass rounded-2xl p-6">
                  <h3 className="font-bold text-foreground mb-4">Follow Us</h3>
                  <div className="space-y-3">
                    {socials.map((social) => (
                      <a
                        key={social.platform}
                        href={social.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 text-sm text-text-muted hover:text-accent transition-colors"
                      >
                        <span className="w-8 h-8 rounded-lg bg-surface-light border border-border flex items-center justify-center text-xs">
                          {social.platform[0].toUpperCase()}
                        </span>
                        {social.platform.charAt(0).toUpperCase() + social.platform.slice(1)}
                      </a>
                    ))}
                  </div>
                </div>
              </ScrollReveal>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

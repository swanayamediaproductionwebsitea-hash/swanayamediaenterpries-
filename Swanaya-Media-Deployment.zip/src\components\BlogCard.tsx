import Link from "next/link";

interface Props {
  title: string;
  slug: string;
  excerpt?: string;
  category?: string;
  published_at?: string;
  read_time?: number;
  author_name?: string;
  featured_image?: string;
}

export default function BlogCard({ title, slug, excerpt, category, published_at, read_time, author_name }: Props) {
  return (
    <Link
      href={`/insights/${slug}`}
      className="group block card-glass rounded-2xl p-6 hover:border-primary/50 transition-all duration-300 hover:-translate-y-1"
    >
      <div className="flex items-center gap-2 mb-3">
        {category && (
          <span className="text-xs bg-accent/10 text-accent px-2 py-0.5 rounded-full">{category}</span>
        )}
        {published_at && (
          <span className="text-xs text-text-muted">{new Date(published_at).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}</span>
        )}
      </div>
      <h3 className="text-lg font-bold text-foreground mb-2 group-hover:text-accent transition-colors line-clamp-2">{title}</h3>
      {excerpt && <p className="text-sm text-text-muted line-clamp-3 mb-4">{excerpt}</p>}
      <div className="flex items-center justify-between text-xs text-text-muted">
        {author_name && <span>By {author_name}</span>}
        {read_time && <span>{read_time} min read</span>}
      </div>
    </Link>
  );
}

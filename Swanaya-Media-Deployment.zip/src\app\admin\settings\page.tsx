"use client";

import { useState, useEffect } from "react";

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch("/api/cms?type=settings").then((r) => r.json()).then((d) => {
      setSettings(d);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const handleSave = async () => {
    try {
      const res = await fetch("/api/cms?type=settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      if (res.ok) {
        setMessage("Settings saved successfully!");
      } else {
        setMessage("Error saving settings");
      }
    } catch { setMessage("Error saving settings"); }
    setTimeout(() => setMessage(""), 3000);
  };

  if (loading) return <p className="text-text-muted">Loading settings...</p>;

  const fields = [
    { key: "company_name", label: "Company Name" },
    { key: "tagline", label: "Tagline" },
    { key: "email", label: "Email" },
    { key: "phone", label: "Phone" },
    { key: "address", label: "Address" },
    { key: "website", label: "Website URL" },
    { key: "description", label: "Company Description", textarea: true },
    { key: "admin_password", label: "Admin Password", type: "password" },
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Settings</h1>
        <button onClick={handleSave} className="btn-primary text-sm py-2 px-5">Save Settings</button>
      </div>

      {message && <div className="bg-accent/10 text-accent text-sm px-4 py-2 rounded-lg mb-4">{message}</div>}

      <div className="card-glass rounded-xl p-6 space-y-6 max-w-2xl">
        {fields.map((field) => (
          <div key={field.key}>
            <label className="block text-sm font-medium text-foreground mb-2">{field.label}</label>
            {field.textarea ? (
              <textarea
                value={settings[field.key] || ""}
                onChange={(e) => setSettings({ ...settings, [field.key]: e.target.value })}
                rows={4}
                className="input-field resize-y"
              />
            ) : (
              <input
                type={field.type || "text"}
                value={settings[field.key] || ""}
                onChange={(e) => setSettings({ ...settings, [field.key]: e.target.value })}
                className="input-field"
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

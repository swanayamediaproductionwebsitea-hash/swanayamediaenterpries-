# SWANAYA MEDIA ENTERPRISES
## Digital Headquarters — Production Build

**Creating Brands. Building Experiences. Growing Businesses.**

A production-ready corporate website + CMS for Swanaya Media Enterprises, built with Next.js 16, React 19, TypeScript, Tailwind CSS 4, React Three Fiber (Three.js) and SQLite.

---

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Install native module dependencies (Windows: build tools required)
npm install -g windows-build-tools   # only on Windows if better-sqlite3 fails
npm rebuild better-sqlite3

# 3. Seed the database (creates swanaya.db with initial content)
npm run seed

# 4. Build for production
npm run build

# 5. Start
npm start
```

Open: **http://localhost:3000**

---

## Admin CMS

| URL | Purpose |
|-----|---------|
| `/admin` | Dashboard + full content management |
| `/admin/analytics` | Visitor analytics, conversion funnel, traffic sources |

**Default admin access is open on localhost.** For production, set the password in `/admin/settings` → `admin_password`, then add authentication to the admin layout.

---

## Project Structure

```
swanaya/
├── src/
│   ├── app/                  # Next.js App Router (pages + API routes)
│   │   ├── page.tsx          # Home — 3D hero + services + blog + FAQ
│   │   ├── about/            # About page
│   │   ├── services/         # Services listing + detail (AEO optimized)
│   │   ├── projects/         # Projects listing + detail
│   │   ├── products/         # Products listing + detail
│   │   ├── team/             # Team listing + member profiles
│   │   ├── insights/         # Blog listing + article pages
│   │   ├── contact/          # Contact + lead capture form
│   │   ├── search/           # Global search
│   │   ├── admin/            # CMS (dashboard, CRUD, analytics, settings)
│   │   ├── api/              # API routes (analytics, leads, cms, search)
│   │   ├── sitemap.ts        # Auto-generated XML sitemap
│   │   └── robots.ts         # robots.txt
│   ├── components/           # Design system + 3D Hero + admin components
│   └── lib/                  # DB, queries, analytics, seed
├── public/
│   ├── landing.html          # Standalone HTML landing page (CDN Three.js)
│   └── ...                   # Static assets
├── swanaya.db                # SQLite database (auto-created on seed)
└── package.json
```

---

## Environment Variables (optional)

Create `.env.local` in the project root:

```
# Used for canonical URLs, sitemap and OG metadata
NEXT_PUBLIC_SITE_URL=https://your-domain.com
```

If unset, defaults to `https://swanayamedia.com`.

---

## Deployment

### Option A — VPS / Cloud Server (recommended)

This app needs a Node.js server (SQLite + SSR + API routes).

```bash
# Upload the ZIP, then:
cd swanaya
npm ci --omit=dev        # or npm install
npm rebuild better-sqlite3   # native module for your OS
npm run seed             # initialize data (skip if already deployed)
npm run build
npm start -- --port 3000
```

Use PM2 for process management:
```bash
npm install -g pm2
pm2 start "npm start" --name swanaya
pm2 save && pm2 startup
```

Reverse proxy with Nginx/Caddy → port 3000. Enable HTTPS.

### Option B — Render / Railway / Fly.io

1. Create account and connect repo or upload the extracted folder
2. Build command: `npm install && npm run seed && npm run build`
3. Start command: `npm start`
4. Add a persistent disk mounted at the project root (to keep `swanaya.db` alive)

### Option C — Vercel (with SQLite caveat)

Serverless environments may not persist `swanaya.db` between cold starts. For a production demo:
- Use Vercel with a persistent filesystem add-on, OR
- Replace `src/lib/db.ts` with a hosted SQLite provider (Turso/LibSQL) — the queries/API layers stay unchanged.

---

## Landing Page

`public/landing.html` is a fully self-contained single-file landing page (Three.js from CDN). It is served at:
```
/landing.html
```
It also posts contact form submissions to `/api/leads`.

---

## Key URLs after deployment

| Route | Notes |
|-------|-------|
| `/` | Home with 3D ecosystem hero |
| `/services` | All services (CMS-driven) |
| `/insights` | Blog (CMS-driven) |
| `/search?q=term` | Global search |
| `/admin` | CMS dashboard |
| `/sitemap.xml` | SEO sitemap |
| `/robots.txt` | Crawler rules |

---

## Important Notes

- **SQLite** stores all content. To back up: copy `swanaya.db` while the app is stopped.
- **First run**: run `npm run seed` before `npm start`.
- **Analytics** are privacy-conscious: no cookies, no fingerprinting, aggregated regions only.
- **SEO/AEO**: every page has metadata; dynamic routes have JSON-LD and answer-first content blocks.
- All service/project/blog/team content is editable from `/admin` — nothing is hardcoded.
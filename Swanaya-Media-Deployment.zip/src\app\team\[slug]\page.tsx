import type { Metadata } from "next";
import { notFound } from "next/navigation";
import ScrollReveal from "@/components/ScrollReveal";
import Breadcrumbs from "@/components/Breadcrumbs";
import { getTeamBySlug } from "@/lib/queries";
import Link from "next/link";

export const dynamic = "force-dynamic";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const member = getTeamBySlug(slug) as Record<string, string> | undefined;
  if (!member) return {};
  return {
    title: member.seo_title || member.name,
    description: member.seo_description || member.bio || "",
  };
}

export default async function TeamMemberPage({ params }: Props) {
  const { slug } = await params;
  const member = getTeamBySlug(slug) as Record<string, string> | undefined;
  if (!member) notFound();

  const personSchema = {
    "@context": "https://schema.org",
    "@type": "Person",
    name: member.name,
    jobTitle: member.role,
    description: member.bio,
    worksFor: { "@type": "Organization", name: "Swanaya Media Enterprises" },
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(personSchema) }} />
      <div className="pt-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Team", href: "/team" }, { label: member.name }]} />

          <ScrollReveal>
            <div className="max-w-4xl py-12 flex flex-col md:flex-row items-start gap-8">
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center text-3xl font-bold text-white flex-shrink-0">
                {member.name.charAt(0)}
              </div>
              <div>
                <h1 className="text-4xl font-bold mb-2">{member.name}</h1>
                {member.role && <p className="text-accent text-lg mb-4">{member.role}</p>}
                {member.bio && <p className="text-text-muted leading-relaxed">{member.bio}</p>}
                <div className="flex gap-4 mt-6">
                  {member.linkedin && (
                    <a href={member.linkedin} target="_blank" rel="noopener noreferrer" className="text-sm text-text-muted hover:text-accent transition-colors">
                      LinkedIn →
                    </a>
                  )}
                  {member.email && (
                    <a href={`mailto:${member.email}`} className="text-sm text-text-muted hover:text-accent transition-colors">
                      Email →
                    </a>
                  )}
                </div>
              </div>
            </div>
          </ScrollReveal>
        </div>

        <section className="py-16 bg-surface">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h2 className="text-2xl font-bold mb-4">Work With Our Team</h2>
            <p className="text-text-muted mb-8">Ready to start your next project with Swanaya Media Enterprises?</p>
            <Link href="/contact" className="btn-primary inline-block">
              Get in Touch
            </Link>
          </div>
        </section>
      </div>
    </>
  );
}

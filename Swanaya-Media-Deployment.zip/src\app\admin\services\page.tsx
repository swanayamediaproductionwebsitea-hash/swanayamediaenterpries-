import CMSList from "@/components/admin/CMSList";

const serviceColumns = [
  { key: "title", label: "Title" },
  { key: "slug", label: "Slug" },
  { key: "short_description", label: "Short Description", textarea: true },
  { key: "icon", label: "Icon" },
  { key: "description", label: "Full Description", textarea: true },
  { key: "features", label: "Features (JSON Array)", textarea: true },
  { key: "process_steps", label: "Process Steps (JSON Array)", textarea: true },
  { key: "sort_order", label: "Sort Order", type: "number" },
  { key: "published", label: "Published", boolean: true },
  { key: "aeo_question", label: "AEO Question", textarea: true },
  { key: "aeo_answer", label: "AEO Answer", textarea: true },
  { key: "seo_title", label: "SEO Title", textarea: true },
  { key: "seo_description", label: "SEO Description", textarea: true },
  { key: "og_title", label: "OG Title" },
  { key: "og_description", label: "OG Description", textarea: true },
  { key: "og_image", label: "OG Image URL" },
];

export default function AdminServicesPage() {
  return <CMSList type="services" columns={serviceColumns} displayName="Services" />;
}

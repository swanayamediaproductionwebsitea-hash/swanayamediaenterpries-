import CMSList from "@/components/admin/CMSList";

const columns = [
  { key: "name", label: "Name" },
  { key: "slug", label: "Slug" },
  { key: "role", label: "Role" },
  { key: "bio", label: "Bio", textarea: true },
  { key: "email", label: "Email" },
  { key: "linkedin", label: "LinkedIn URL" },
  { key: "twitter", label: "Twitter URL" },
  { key: "sort_order", label: "Sort Order", type: "number" },
  { key: "published", label: "Published", boolean: true },
];

export default function AdminTeamPage() {
  return <CMSList type="team" columns={columns} displayName="Team Members" />;
}

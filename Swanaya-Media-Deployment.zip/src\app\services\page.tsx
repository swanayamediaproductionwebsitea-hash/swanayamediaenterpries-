import type { Metadata } from "next";
import ScrollReveal from "@/components/ScrollReveal";
import ServiceCard from "@/components/ServiceCard";
import Breadcrumbs from "@/components/Breadcrumbs";
import { getServices } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Services",
  description: "Explore Swanaya Media Enterprises' comprehensive digital services — digital marketing, web development, branding, video production, social media and business consultancy.",
};

export default function ServicesPage() {
  const services = getServices() as { id: string; title: string; slug: string; short_description: string; icon: string; features: string }[];

  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Services" }]} />

        <ScrollReveal>
          <div className="max-w-4xl py-12">
            <span className="text-accent text-sm font-semibold uppercase tracking-wider">Our Services</span>
            <h1 className="text-4xl sm:text-5xl font-bold mt-2 mb-6">
              Comprehensive <span className="gradient-text">Digital Solutions</span>
            </h1>
            <p className="text-text-muted text-lg">
              Swanaya Media Enterprises provides end-to-end digital solutions designed to create brands, build experiences and grow businesses. Our services span the full digital spectrum.
            </p>
          </div>
        </ScrollReveal>
      </div>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, i) => (
              <ScrollReveal key={service.id} delay={i * 100}>
                <ServiceCard
                  title={service.title}
                  description={service.short_description || ""}
                  icon={service.icon}
                  href={`/services/${service.slug}`}
                  features={service.features ? JSON.parse(service.features) : []}
                />
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-surface">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <ScrollReveal>
            <h2 className="text-3xl font-bold mb-4">Need a Custom Solution?</h2>
            <p className="text-text-muted mb-8">
              Every business is unique. Contact us to discuss your specific requirements and we will tailor a solution for you.
            </p>
            <a href="/contact" className="btn-primary inline-block">
              Get in Touch
            </a>
          </ScrollReveal>
        </div>
      </section>
    </div>
  );
}

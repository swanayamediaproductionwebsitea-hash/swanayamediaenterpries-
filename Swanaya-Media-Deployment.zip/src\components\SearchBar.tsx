"use client";

import { useState, useEffect, useCallback } from "react";
import { useRouter } from "next/navigation";
import { trackEvent } from "@/lib/analytics-client";

export default function SearchBar() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<{ type: string; title: string; slug: string; excerpt: string; url: string }[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const router = useRouter();

  const search = useCallback(async (q: string) => {
    if (!q.trim()) { setResults([]); return; }
    try {
      const res = await fetch(`/api/search?q=${encodeURIComponent(q)}`);
      const data = await res.json();
      setResults(data.results || []);
    } catch { setResults([]); }
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => search(query), 300);
    return () => clearTimeout(timer);
  }, [query, search]);

  const handleSelect = (url: string) => {
    trackEvent("search_performed", { search_query: query });
    setIsOpen(false);
    setQuery("");
    router.push(url);
  };

  return (
    <div className="relative">
      <div className="relative">
        <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-text-muted" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
        <input
          type="text"
          value={query}
          onChange={(e) => { setQuery(e.target.value); setIsOpen(true); }}
          onFocus={() => setIsOpen(true)}
          placeholder="Search services, projects, articles..."
          className="input-field pl-10"
        />
      </div>
      {isOpen && results.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-surface border border-border rounded-xl shadow-xl max-h-96 overflow-y-auto z-50">
          {results.map((r, i) => (
            <button
              key={i}
              onClick={() => handleSelect(r.url)}
              className="w-full px-4 py-3 text-left hover:bg-surface-light transition-colors border-b border-border last:border-0"
            >
              <div className="flex items-center gap-2">
                <span className="text-xs bg-primary/20 text-primary-light px-2 py-0.5 rounded-full">{r.type}</span>
                <span className="font-medium text-foreground text-sm">{r.title}</span>
              </div>
              {r.excerpt && <p className="text-xs text-text-muted mt-1 line-clamp-1">{r.excerpt}</p>}
            </button>
          ))}
        </div>
      )}
      {isOpen && query && results.length === 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-surface border border-border rounded-xl p-4 text-center text-text-muted text-sm z-50">
          No results found for &quot;{query}&quot;
        </div>
      )}
    </div>
  );
}

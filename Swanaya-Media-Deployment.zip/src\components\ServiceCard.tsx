import Link from "next/link";

interface Props {
  title: string;
  description?: string;
  icon?: string;
  href?: string;
  features?: string[];
}

export default function ServiceCard({ title, description, icon, href, features }: Props) {
  if (href) {
    return (
      <Link
        href={href}
        className="group block card-glass rounded-2xl p-6 hover:border-primary/50 transition-all duration-300 hover:-translate-y-1"
      >
        {icon && <div className="text-3xl mb-4">{icon}</div>}
        <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-accent transition-colors">{title}</h3>
        {description && <p className="text-text-muted text-sm leading-relaxed mb-4">{description}</p>}
        {features && features.length > 0 && (
          <ul className="space-y-1.5">
            {features.slice(0, 4).map((f, i) => (
              <li key={i} className="text-xs text-text-muted flex items-center gap-2">
                <span className="w-1 h-1 rounded-full bg-accent flex-shrink-0" />
                {f}
              </li>
            ))}
          </ul>
        )}
        <div className="mt-4 text-sm text-accent group-hover:translate-x-1 transition-transform inline-flex items-center gap-1">
          Learn more →
        </div>
      </Link>
    );
  }

  return (
    <div
      className="group block card-glass rounded-2xl p-6 hover:border-primary/50 transition-all duration-300 hover:-translate-y-1"
    >
      {icon && <div className="text-3xl mb-4">{icon}</div>}
      <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-accent transition-colors">{title}</h3>
      {description && <p className="text-text-muted text-sm leading-relaxed mb-4">{description}</p>}
      {features && features.length > 0 && (
        <ul className="space-y-1.5">
          {features.slice(0, 4).map((f, i) => (
            <li key={i} className="text-xs text-text-muted flex items-center gap-2">
              <span className="w-1 h-1 rounded-full bg-accent flex-shrink-0" />
              {f}
            </li>
          ))}
        </ul>
      )}
      {href && (
        <div className="mt-4 text-sm text-accent group-hover:translate-x-1 transition-transform inline-flex items-center gap-1">
          Learn more →
        </div>
      )}
    </div>
  );
}

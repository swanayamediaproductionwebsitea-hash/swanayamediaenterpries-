import { NextRequest } from "next/server";
import getDb from "@/lib/db";
import { generateId } from "@/lib/utils";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const db = getDb();

    const {
      event_type,
      page,
      service,
      project,
      product,
      blog,
      search_query,
      source,
      medium,
      campaign,
      device,
      session_id,
    } = body;

    if (!event_type) {
      return Response.json({ error: "event_type required" }, { status: 400 });
    }

    const region = "approximate";

    db.prepare(`
      INSERT INTO analytics_events (event_type, page, service, project, product, blog, search_query, source, medium, campaign, device, region, session_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      event_type,
      page || null,
      service || null,
      project || null,
      product || null,
      blog || null,
      search_query || null,
      source || null,
      medium || null,
      campaign || null,
      device || null,
      region,
      session_id || null
    );

    if (session_id) {
      const existing = db.prepare("SELECT id FROM analytics_sessions WHERE id = ?").get(session_id);
      if (existing) {
        db.prepare(`
          UPDATE analytics_sessions 
          SET last_active = datetime('now'), page_views = page_views + 1
          WHERE id = ?
        `).run(session_id);
      } else {
        db.prepare(`
          INSERT INTO analytics_sessions (id, device, source, medium, campaign)
          VALUES (?, ?, ?, ?, ?)
        `).run(session_id, device || null, source || null, medium || null, campaign || null);
      }
    }

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: "Failed to track event" }, { status: 500 });
  }
}

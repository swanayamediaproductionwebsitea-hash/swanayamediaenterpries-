"use client";

export function trackEvent(eventType: string, data: Record<string, string> = {}) {
  if (typeof window === "undefined") return;

  const sessionId = getOrCreateSessionId();
  const device = getDeviceType();

  const payload = {
    event_type: eventType,
    session_id: sessionId,
    device,
    page: window.location.pathname,
    ...data,
  };

  fetch("/api/analytics/track", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
    keepalive: true,
  }).catch(() => {});
}

function getOrCreateSessionId(): string {
  if (typeof window === "undefined") return "";
  let id = sessionStorage.getItem("swanaya_session");
  if (!id) {
    id = crypto.randomUUID();
    sessionStorage.setItem("swanaya_session", id);
  }
  return id;
}

function getDeviceType(): string {
  if (typeof window === "undefined") return "unknown";
  const w = window.innerWidth;
  if (w < 768) return "mobile";
  if (w < 1024) return "tablet";
  return "desktop";
}

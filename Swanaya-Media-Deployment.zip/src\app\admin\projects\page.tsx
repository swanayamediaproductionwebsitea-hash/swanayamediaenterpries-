import CMSList from "@/components/admin/CMSList";

const columns = [
  { key: "title", label: "Title" },
  { key: "slug", label: "Slug" },
  { key: "short_description", label: "Short Description", textarea: true },
  { key: "description", label: "Full Description", textarea: true },
  { key: "client", label: "Client" },
  { key: "category", label: "Category", type: "select", options: ["Digital Marketing", "Web Development", "Branding", "Video Production", "Social Media", "Consultancy"] },
  { key: "services", label: "Related Services (JSON Array)", textarea: true },
  { key: "results", label: "Results (JSON Array)", textarea: true },
  { key: "featured", label: "Featured", boolean: true },
  { key: "published", label: "Published", boolean: true },
  { key: "seo_title", label: "SEO Title" },
  { key: "seo_description", label: "SEO Description", textarea: true },
  { key: "og_title", label: "OG Title" },
  { key: "og_description", label: "OG Description", textarea: true },
  { key: "og_image", label: "OG Image URL" },
];

export default function AdminProjectsPage() {
  return <CMSList type="projects" columns={columns} displayName="Projects" />;
}

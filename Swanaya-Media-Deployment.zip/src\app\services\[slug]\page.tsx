import type { Metadata } from "next";
import { notFound } from "next/navigation";
import ScrollReveal from "@/components/ScrollReveal";
import Breadcrumbs from "@/components/Breadcrumbs";
import FAQSection from "@/components/FAQSection";
import { getServiceBySlug, getServices, getProjects, getFaqs } from "@/lib/queries";
import { parseJsonArray } from "@/lib/utils";
import Link from "next/link";

export const dynamic = "force-dynamic";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const service = getServiceBySlug(slug) as Record<string, string> | undefined;
  if (!service) return {};
  return {
    title: service.seo_title || service.title,
    description: service.seo_description || service.short_description || "",
    openGraph: {
      title: service.og_title || service.title,
      description: service.og_description || service.short_description || "",
      images: service.og_image ? [service.og_image] : [],
    },
  };
}

export default async function ServiceDetailPage({ params }: Props) {
  const { slug } = await params;
  const service = getServiceBySlug(slug) as Record<string, string> | undefined;
  if (!service) notFound();

  const features = parseJsonArray<string>(service.features);
  const processSteps = parseJsonArray<string>(service.process_steps);
  const allServices = getServices() as { id: string; title: string; slug: string }[];
  const relatedProjects = getProjects() as { id: string; title: string; slug: string; short_description: string; client: string; category: string }[];

  const serviceSchema = {
    "@context": "https://schema.org",
    "@type": "Service",
    name: service.title,
    description: service.short_description || "",
    provider: {
      "@type": "Organization",
      name: "Swanaya Media Enterprises",
    },
    url: `https://swanayamedia.com/services/${service.slug}`,
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceSchema) }} />
      <div className="pt-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Services", href: "/services" }, { label: service.title }]} />

          <ScrollReveal>
            <div className="max-w-4xl py-12">
              {service.icon && <div className="text-5xl mb-4">{service.icon}</div>}
              <h1 className="text-4xl sm:text-5xl font-bold mb-4">{service.title}</h1>
              {service.short_description && (
                <p className="text-text-muted text-lg">{service.short_description}</p>
              )}
            </div>
          </ScrollReveal>
        </div>

        {/* AEO Answer Box */}
        {service.aeo_answer && (
          <section className="py-12 bg-surface">
            <div className="max-w-4xl mx-auto px-4">
              <ScrollReveal>
                <div className="card-glass rounded-2xl p-8">
                  <h2 className="text-lg font-semibold text-foreground mb-3">{service.aeo_question || `What is ${service.title}?`}</h2>
                  <p className="text-text-muted leading-relaxed">{service.aeo_answer}</p>
                </div>
              </ScrollReveal>
            </div>
          </section>
        )}

        {/* Features */}
        {features.length > 0 && (
          <section className="py-16">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <ScrollReveal>
                <h2 className="text-3xl font-bold mb-8">What We Offer</h2>
              </ScrollReveal>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {features.map((feature, i) => (
                  <ScrollReveal key={i} delay={i * 80}>
                    <div className="card-glass rounded-xl p-5 flex items-start gap-3">
                      <span className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-accent text-xs">✓</span>
                      </span>
                      <span className="text-foreground text-sm">{feature}</span>
                    </div>
                  </ScrollReveal>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Process */}
        {processSteps.length > 0 && (
          <section className="py-16 bg-surface">
            <div className="max-w-4xl mx-auto px-4">
              <ScrollReveal>
                <h2 className="text-3xl font-bold mb-8">Our Process</h2>
              </ScrollReveal>
              <div className="space-y-4">
                {processSteps.map((step, i) => (
                  <ScrollReveal key={i} delay={i * 100}>
                    <div className="flex items-start gap-4 card-glass rounded-xl p-5">
                      <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                        <span className="text-primary-light font-bold text-sm">{i + 1}</span>
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">{step}</h3>
                      </div>
                    </div>
                  </ScrollReveal>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Full Description */}
        {service.description && (
          <section className="py-16">
            <div className="max-w-4xl mx-auto px-4">
              <ScrollReveal>
                <h2 className="text-3xl font-bold mb-8">About {service.title}</h2>
                <div className="prose prose-invert max-w-none text-text-muted leading-relaxed" dangerouslySetInnerHTML={{ __html: service.description }} />
              </ScrollReveal>
            </div>
          </section>
        )}

        {/* CTA */}
        <section className="py-24 bg-gradient-to-r from-primary/10 to-accent/10">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <ScrollReveal>
              <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
              <p className="text-text-muted mb-8">Let&apos;s discuss how {service.title} can help your business grow.</p>
              <Link href="/contact" className="btn-primary inline-block text-lg px-10 py-4">
                Start a Project
              </Link>
            </ScrollReveal>
          </div>
        </section>

        {/* Other Services */}
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ScrollReveal>
              <h2 className="text-2xl font-bold mb-8">Other Services</h2>
            </ScrollReveal>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {allServices.filter((s) => s.slug !== slug).slice(0, 3).map((s, i) => (
                <ScrollReveal key={s.id} delay={i * 100}>
                  <Link href={`/services/${s.slug}`} className="card-glass rounded-xl p-5 block hover:border-primary/50 transition-all">
                    <h3 className="font-semibold text-foreground hover:text-accent transition-colors">{s.title}</h3>
                  </Link>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </section>
      </div>
    </>
  );
}

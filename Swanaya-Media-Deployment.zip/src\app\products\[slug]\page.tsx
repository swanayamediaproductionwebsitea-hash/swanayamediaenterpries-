import type { Metadata } from "next";
import { notFound } from "next/navigation";
import ScrollReveal from "@/components/ScrollReveal";
import Breadcrumbs from "@/components/Breadcrumbs";
import { getProductBySlug, getProducts } from "@/lib/queries";
import { parseJsonArray } from "@/lib/utils";
import Link from "next/link";

export const dynamic = "force-dynamic";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const product = getProductBySlug(slug) as Record<string, string> | undefined;
  if (!product) return {};
  return {
    title: product.seo_title || product.title,
    description: product.seo_description || product.short_description || "",
  };
}

export default async function ProductDetailPage({ params }: Props) {
  const { slug } = await params;
  const product = getProductBySlug(slug) as Record<string, string> | undefined;
  if (!product) notFound();

  const features = parseJsonArray<string>(product.features);

  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Products", href: "/products" }, { label: product.title }]} />

        <ScrollReveal>
          <div className="max-w-4xl py-12">
            {product.category && <span className="text-xs bg-accent/10 text-accent px-3 py-1 rounded-full">{product.category}</span>}
            <h1 className="text-4xl sm:text-5xl font-bold mt-4 mb-4">{product.title}</h1>
            {product.short_description && <p className="text-text-muted text-lg">{product.short_description}</p>}
          </div>
        </ScrollReveal>
      </div>

      {product.description && (
        <section className="py-16">
          <div className="max-w-4xl mx-auto px-4">
            <ScrollReveal>
              <div className="prose prose-invert max-w-none text-text-muted leading-relaxed" dangerouslySetInnerHTML={{ __html: product.description }} />
            </ScrollReveal>
          </div>
        </section>
      )}

      {features.length > 0 && (
        <section className="py-16 bg-surface">
          <div className="max-w-4xl mx-auto px-4">
            <h2 className="text-3xl font-bold mb-8">Features</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {features.map((f, i) => (
                <div key={i} className="card-glass rounded-xl p-5 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-accent text-xs">✓</span>
                  </span>
                  <span className="text-foreground text-sm">{f}</span>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      <section className="py-24 bg-gradient-to-r from-primary/10 to-accent/10">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Interested in {product.title}?</h2>
          <p className="text-text-muted mb-8">Contact us to learn more or request a demo.</p>
          <Link href="/contact" className="btn-primary inline-block text-lg px-10 py-4">
            Get in Touch
          </Link>
        </div>
      </section>
    </div>
  );
}

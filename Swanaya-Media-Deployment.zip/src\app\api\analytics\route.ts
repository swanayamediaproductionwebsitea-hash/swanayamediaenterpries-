import { NextRequest } from "next/server";
import getDb from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    const db = getDb();
    const { searchParams } = new URL(request.url);
    const period = searchParams.get("period") || "7d";

    let dateFilter = "datetime('now', '-7 days')";
    if (period === "30d") dateFilter = "datetime('now', '-30 days')";
    else if (period === "90d") dateFilter = "datetime('now', '-90 days')";
    else if (period === "1d") dateFilter = "datetime('now', '-1 day')";

    const totalEvents = db.prepare(`
      SELECT COUNT(*) as count FROM analytics_events WHERE created_at >= ${dateFilter}
    `).get() as { count: number };

    const uniqueSessions = db.prepare(`
      SELECT COUNT(DISTINCT session_id) as count FROM analytics_events WHERE created_at >= ${dateFilter} AND session_id IS NOT NULL
    `).get() as { count: number };

    const eventBreakdown = db.prepare(`
      SELECT event_type, COUNT(*) as count FROM analytics_events 
      WHERE created_at >= ${dateFilter}
      GROUP BY event_type ORDER BY count DESC
    `).all() as { event_type: string; count: number }[];

    const topPages = db.prepare(`
      SELECT page, COUNT(*) as count FROM analytics_events 
      WHERE created_at >= ${dateFilter} AND page IS NOT NULL
      GROUP BY page ORDER BY count DESC LIMIT 10
    `).all() as { page: string; count: number }[];

    const topServices = db.prepare(`
      SELECT service, COUNT(*) as count FROM analytics_events 
      WHERE created_at >= ${dateFilter} AND service IS NOT NULL
      GROUP BY service ORDER BY count DESC LIMIT 10
    `).all() as { service: string; count: number }[];

    const deviceBreakdown = db.prepare(`
      SELECT device, COUNT(*) as count FROM analytics_events 
      WHERE created_at >= ${dateFilter} AND device IS NOT NULL
      GROUP BY device ORDER BY count DESC
    `).all() as { device: string; count: number }[];

    const sourceBreakdown = db.prepare(`
      SELECT source, COUNT(*) as count FROM analytics_events 
      WHERE created_at >= ${dateFilter} AND source IS NOT NULL
      GROUP BY source ORDER BY count DESC
    `).all() as { source: string; count: number }[];

    const activeSessions = db.prepare(`
      SELECT COUNT(*) as count FROM analytics_sessions 
      WHERE last_active >= datetime('now', '-15 minutes')
    `).get() as { count: number };

    const recentEvents = db.prepare(`
      SELECT event_type, page, service, device, created_at 
      FROM analytics_events ORDER BY created_at DESC LIMIT 20
    `).all();

    const leads = db.prepare(`
      SELECT COUNT(*) as count FROM leads WHERE created_at >= ${dateFilter}
    `).get() as { count: number };

    const conversions = db.prepare(`
      SELECT 
        SUM(CASE WHEN event_type = 'page_view' THEN 1 ELSE 0 END) as visitors,
        SUM(CASE WHEN event_type = 'service_view' THEN 1 ELSE 0 END) as service_views,
        SUM(CASE WHEN event_type = 'cta_click' THEN 1 ELSE 0 END) as cta_clicks,
        SUM(CASE WHEN event_type = 'contact_form_submitted' THEN 1 ELSE 0 END) as contacts
      FROM analytics_events WHERE created_at >= ${dateFilter}
    `).get();

    return Response.json({
      overview: {
        totalEvents: totalEvents.count,
        uniqueSessions: uniqueSessions.count,
        activeSessions: activeSessions.count,
        leads: leads.count,
      },
      eventBreakdown,
      topPages,
      topServices,
      deviceBreakdown,
      sourceBreakdown,
      recentEvents,
      conversions,
    });
  } catch (error) {
    return Response.json({ error: "Failed to fetch analytics" }, { status: 500 });
  }
}

import getDb from "@/lib/db";
import { MetadataRoute } from "next";

export const dynamic = "force-dynamic";

export default function sitemap(): MetadataRoute.Sitemap {
  const db = getDb();
  const baseUrl = "https://swanayamedia.com";
  const entries: MetadataRoute.Sitemap = [];

  const staticPages = ["", "/about", "/services", "/projects", "/products", "/team", "/insights", "/contact"];
  for (const page of staticPages) {
    entries.push({ url: `${baseUrl}${page}`, lastModified: new Date(), changeFrequency: "weekly", priority: page === "" ? 1 : 0.8 });
  }

  const services = db.prepare("SELECT slug, updated_at FROM services WHERE published = 1").all() as { slug: string; updated_at: string }[];
  for (const s of services) {
    entries.push({ url: `${baseUrl}/services/${s.slug}`, lastModified: new Date(s.updated_at), changeFrequency: "monthly", priority: 0.7 });
  }

  const projects = db.prepare("SELECT slug, updated_at FROM projects WHERE published = 1").all() as { slug: string; updated_at: string }[];
  for (const p of projects) {
    entries.push({ url: `${baseUrl}/projects/${p.slug}`, lastModified: new Date(p.updated_at), changeFrequency: "monthly", priority: 0.6 });
  }

  const products = db.prepare("SELECT slug, updated_at FROM products WHERE published = 1").all() as { slug: string; updated_at: string }[];
  for (const p of products) {
    entries.push({ url: `${baseUrl}/products/${p.slug}`, lastModified: new Date(p.updated_at), changeFrequency: "monthly", priority: 0.6 });
  }

  const blogs = db.prepare("SELECT slug, updated_at FROM blog WHERE published = 1").all() as { slug: string; updated_at: string }[];
  for (const b of blogs) {
    entries.push({ url: `${baseUrl}/insights/${b.slug}`, lastModified: new Date(b.updated_at), changeFrequency: "monthly", priority: 0.6 });
  }

  const teamMembers = db.prepare("SELECT slug, updated_at FROM team WHERE published = 1").all() as { slug: string; updated_at: string }[];
  for (const t of teamMembers) {
    entries.push({ url: `${baseUrl}/team/${t.slug}`, lastModified: new Date(t.updated_at), changeFrequency: "monthly", priority: 0.5 });
  }

  return entries;
}

// One-command setup for the deploy server.
// Include this with the deployment zip.

const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");

function run(cmd) {
  console.log(`\n> ${cmd}`);
  execSync(cmd, { stdio: "inherit", cwd: __dirname });
}

console.log("==============================================");
console.log("  SWANAYA MEDIA ENTERPRISES — DEPLOY SETUP");
console.log("==============================================");

// 1. Install dependencies
run("npm install");

// 2. Rebuild native module for this OS
try {
  run("npm rebuild better-sqlite3");
} catch (e) {
  console.log("WARN: better-sqlite3 rebuild failed. On Windows install build tools first.");
}

// 3. Seed database if not present
if (!fs.existsSync(path.join(__dirname, "swanaya.db"))) {
  run("npm run seed");
} else {
  console.log("\n> swanaya.db already exists, skipping seed.");
}

// 4. Production build
run("npm run build");

console.log("\n==============================================");
console.log("  DEPLOYMENT READY ✓");
console.log("  Start with:  npm start");
console.log("==============================================");
import CMSList from "@/components/admin/CMSList";

const columns = [
  { key: "title", label: "Title" },
  { key: "slug", label: "Slug" },
  { key: "short_description", label: "Short Description", textarea: true },
  { key: "description", label: "Full Description", textarea: true },
  { key: "category", label: "Category" },
  { key: "features", label: "Features (JSON Array)", textarea: true },
  { key: "pricing", label: "Pricing", textarea: true },
  { key: "demo_url", label: "Demo URL" },
  { key: "published", label: "Published", boolean: true },
  { key: "seo_title", label: "SEO Title" },
  { key: "seo_description", label: "SEO Description", textarea: true },
];

export default function AdminProductsPage() {
  return <CMSList type="products" columns={columns} displayName="Products" />;
}

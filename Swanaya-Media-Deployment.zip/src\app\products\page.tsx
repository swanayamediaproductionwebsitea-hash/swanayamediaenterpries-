import type { Metadata } from "next";
import ScrollReveal from "@/components/ScrollReveal";
import Breadcrumbs from "@/components/Breadcrumbs";
import { getProducts } from "@/lib/queries";
import Link from "next/link";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Products",
  description: "Explore Swanaya Media Enterprises' products and digital solutions designed to help businesses grow.",
};

export default function ProductsPage() {
  const products = getProducts() as { id: string; title: string; slug: string; short_description: string; category: string; features: string }[];

  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Products" }]} />
        <ScrollReveal>
          <div className="max-w-4xl py-12">
            <span className="text-accent text-sm font-semibold uppercase tracking-wider">Products</span>
            <h1 className="text-4xl sm:text-5xl font-bold mt-2 mb-6">
              Digital <span className="gradient-text">Products</span>
            </h1>
            <p className="text-text-muted text-lg">
              Explore our range of digital products and solutions designed to streamline your business operations.
            </p>
          </div>
        </ScrollReveal>
      </div>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {products.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {products.map((product, i) => (
                <ScrollReveal key={product.id} delay={i * 100}>
                  <Link href={`/products/${product.slug}`} className="group block card-glass rounded-2xl p-6 hover:border-primary/50 transition-all duration-300 hover:-translate-y-1">
                    <h3 className="text-xl font-bold text-foreground mb-2 group-hover:text-accent transition-colors">{product.title}</h3>
                    {product.category && <span className="text-xs bg-accent/10 text-accent px-2 py-0.5 rounded-full">{product.category}</span>}
                    {product.short_description && <p className="text-sm text-text-muted mt-3">{product.short_description}</p>}
                  </Link>
                </ScrollReveal>
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <p className="text-text-muted text-lg">Products coming soon. Check back later.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

import { NextRequest } from "next/server";
import getDb from "@/lib/db";

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const q = searchParams.get("q") || "";

  if (!q.trim()) {
    return Response.json({ results: [], suggestions: [] });
  }

  const db = getDb();
  const pattern = `%${q}%`;
  const results: { type: string; title: string; slug: string; excerpt: string; url: string }[] = [];

  const services = db.prepare(
    "SELECT title, slug, short_description FROM services WHERE published = 1 AND (title LIKE ? OR short_description LIKE ?) LIMIT 5"
  ).all(pattern, pattern) as { title: string; slug: string; short_description: string }[];
  for (const s of services) {
    results.push({ type: "service", title: s.title, slug: s.slug, excerpt: s.short_description || "", url: `/services/${s.slug}` });
  }

  const projects = db.prepare(
    "SELECT title, slug, short_description FROM projects WHERE published = 1 AND (title LIKE ? OR short_description LIKE ?) LIMIT 5"
  ).all(pattern, pattern) as { title: string; slug: string; short_description: string }[];
  for (const p of projects) {
    results.push({ type: "project", title: p.title, slug: p.slug, excerpt: p.short_description || "", url: `/projects/${p.slug}` });
  }

  const products = db.prepare(
    "SELECT title, slug, short_description FROM products WHERE published = 1 AND (title LIKE ? OR short_description LIKE ?) LIMIT 5"
  ).all(pattern, pattern) as { title: string; slug: string; short_description: string }[];
  for (const p of products) {
    results.push({ type: "product", title: p.title, slug: p.slug, excerpt: p.short_description || "", url: `/products/${p.slug}` });
  }

  const blogs = db.prepare(
    "SELECT title, slug, excerpt FROM blog WHERE published = 1 AND (title LIKE ? OR excerpt LIKE ?) LIMIT 5"
  ).all(pattern, pattern) as { title: string; slug: string; excerpt: string }[];
  for (const b of blogs) {
    results.push({ type: "blog", title: b.title, slug: b.slug, excerpt: b.excerpt || "", url: `/insights/${b.slug}` });
  }

  const teamMembers = db.prepare(
    "SELECT name, slug, role FROM team WHERE published = 1 AND (name LIKE ? OR role LIKE ?) LIMIT 5"
  ).all(pattern, pattern) as { name: string; slug: string; role: string }[];
  for (const t of teamMembers) {
    results.push({ type: "team", title: t.name, slug: t.slug, excerpt: t.role || "", url: `/team/${t.slug}` });
  }

  db.prepare(
    "INSERT INTO analytics_events (event_type, search_query, session_id) VALUES ('search_performed', ?, ?)"
  ).run(q, searchParams.get("session_id") || null);

  const suggestions = results.length === 0
    ? ["digital marketing", "web development", "branding", "video production", "consultancy"]
    : [];

  return Response.json({ results, suggestions });
}

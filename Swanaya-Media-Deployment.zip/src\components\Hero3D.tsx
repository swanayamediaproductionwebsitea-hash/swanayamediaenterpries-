"use client";

import { useRef, useMemo, useState, useEffect } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Float, Text, Stars } from "@react-three/drei";
import * as THREE from "three";

const NODES = [
  { label: "MEDIA", angle: 0, color: "#8b5cf6" },
  { label: "MARKETING", angle: 45, color: "#00d4aa" },
  { label: "TECHNOLOGY", angle: 90, color: "#6c3ce0" },
  { label: "BRANDING", angle: 135, color: "#fbbf24" },
  { label: "WEB", angle: 180, color: "#f472b6" },
  { label: "CONSULTANCY", angle: 225, color: "#34d399" },
  { label: "GROWTH", angle: 270, color: "#60a5fa" },
  { label: "SOCIAL", angle: 315, color: "#fb923c" },
];

function CenterNode() {
  const ref = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.elapsedTime * 0.2;
      const scale = hovered ? 1.15 : 1;
      ref.current.scale.lerp(new THREE.Vector3(scale, scale, scale), 0.1);
    }
  });

  return (
    <mesh
      ref={ref}
      onPointerEnter={() => setHovered(true)}
      onPointerLeave={() => setHovered(false)}
    >
      <icosahedronGeometry args={[0.8, 1]} />
      <meshStandardMaterial
        color="#6c3ce0"
        emissive="#6c3ce0"
        emissiveIntensity={0.4}
        wireframe
        transparent
        opacity={0.8}
      />
    </mesh>
  );
}

function OrbitalNode({
  label,
  angle,
  color,
  index,
}: {
  label: string;
  angle: number;
  color: string;
  index: number;
}) {
  const ref = useRef<THREE.Group>(null);
  const [hovered, setHovered] = useState(false);
  const radius = 3.2;
  const rad = (angle * Math.PI) / 180;

  useFrame((state) => {
    if (ref.current) {
      const t = state.clock.elapsedTime * 0.15;
      const r = radius + Math.sin(state.clock.elapsedTime * 0.5 + index) * 0.3;
      ref.current.position.x = Math.cos(rad + t) * r;
      ref.current.position.z = Math.sin(rad + t) * r;
      ref.current.position.y = Math.sin(state.clock.elapsedTime * 0.7 + index * 0.8) * 0.4;
    }
  });

  return (
    <group
      ref={ref}
      onPointerEnter={() => setHovered(true)}
      onPointerLeave={() => setHovered(false)}
    >
      <mesh>
        <sphereGeometry args={[hovered ? 0.35 : 0.25, 16, 16]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={hovered ? 0.8 : 0.3}
          transparent
          opacity={0.9}
        />
      </mesh>
      <Text
        position={[0, 0.5, 0]}
        fontSize={0.18}
        color={hovered ? "#ffffff" : "#aaaacc"}
        anchorX="center"
        anchorY="bottom"
        font={undefined}
      >
        {label}
      </Text>
      <ConnectionLine />
    </group>
  );
}

function ConnectionLine() {
  const ref = useRef<THREE.Line>(null);
  return null;
}

function Particles() {
  const count = 200;
  const positions = useMemo(() => {
    const pos = new Float32Array(count * 3);
    for (let i = 0; i < count * 3; i++) {
      pos[i] = (Math.random() - 0.5) * 15;
    }
    return pos;
  }, []);

  const ref = useRef<THREE.Points>(null);

  useFrame((state) => {
    if (ref.current) {
      ref.current.rotation.y = state.clock.elapsedTime * 0.02;
    }
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
      </bufferGeometry>
      <pointsMaterial size={0.03} color="#6c3ce0" transparent opacity={0.6} sizeAttenuation />
    </points>
  );
}

function Scene() {
  const { camera } = useThree();

  useEffect(() => {
    camera.position.set(0, 2, 7);
    camera.lookAt(0, 0, 0);
  }, [camera]);

  return (
    <>
      <ambientLight intensity={0.3} />
      <pointLight position={[5, 5, 5]} intensity={0.8} color="#8b5cf6" />
      <pointLight position={[-5, 3, -5]} intensity={0.5} color="#00d4aa" />
      <pointLight position={[0, -3, 0]} intensity={0.3} color="#fbbf24" />
      <Stars radius={50} depth={50} count={500} factor={2} saturation={0} fade speed={0.5} />
      <Particles />
      <CenterNode />
      {NODES.map((node, i) => (
        <OrbitalNode key={node.label} {...node} index={i} />
      ))}
    </>
  );
}

export default function Hero3D() {
  const [hasReducedMotion, setHasReducedMotion] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    setHasReducedMotion(window.matchMedia("(prefers-reduced-motion: reduce)").matches);
    setIsMobile(window.innerWidth < 768);
  }, []);

  return (
    <div className="relative w-full h-[70vh] lg:h-[85vh] hero-gradient">
      <div className="absolute inset-0 z-0">
        {!hasReducedMotion && (
          <Canvas
            camera={{ position: [0, 2, 7], fov: 50 }}
            dpr={isMobile ? [1, 1.5] : [1, 2]}
            gl={{ antialias: true, alpha: true }}
            style={{ background: "transparent" }}
          >
            <Scene />
          </Canvas>
        )}
      </div>

      <div className="absolute inset-0 z-10 flex items-center justify-center pointer-events-none">
        <div className="text-center px-4 max-w-4xl">
          <div className="inline-flex items-center gap-2 bg-surface/60 backdrop-blur-sm border border-border rounded-full px-4 py-2 mb-6">
            <span className="w-2 h-2 rounded-full bg-accent animate-pulse-glow" />
            <span className="text-xs text-text-muted">Kerala-Based, Globally Oriented</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-7xl font-bold leading-tight mb-4">
            <span className="gradient-text">SWANAYA</span>
            <br />
            <span className="text-foreground/80 text-2xl sm:text-3xl lg:text-4xl font-light">Digital Ecosystem</span>
          </h1>
          <p className="text-text-muted text-lg sm:text-xl max-w-2xl mx-auto mb-8 leading-relaxed">
            Creating Brands. Building Experiences. Growing Businesses.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pointer-events-auto">
            <a href="/services" className="btn-primary text-base px-8 py-3">
              Explore Services
            </a>
            <a href="/contact" className="btn-accent text-base px-8 py-3">
              Start a Project
            </a>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce">
        <svg className="w-6 h-6 text-text-muted" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </div>
  );
}

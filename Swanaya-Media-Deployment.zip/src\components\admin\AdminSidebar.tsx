"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";

const menuItems = [
  { href: "/admin", label: "Dashboard", icon: "◆" },
  { href: "/admin/services", label: "Services", icon: "★" },
  { href: "/admin/projects", label: "Projects", icon: "▲" },
  { href: "/admin/products", label: "Products", icon: "●" },
  { href: "/admin/team", label: "Team", icon: "■" },
  { href: "/admin/blog", label: "Blog", icon: "✦" },
  { href: "/admin/leads", label: "Leads", icon: "→" },
  { href: "/admin/analytics", label: "Analytics", icon: "◇" },
  { href: "/admin/social", label: "Social", icon: "◎" },
  { href: "/admin/faqs", label: "FAQs", icon: "?" },
  { href: "/admin/media", label: "Media", icon: "□" },
  { href: "/admin/pages", label: "Pages", icon: "≡" },
  { href: "/admin/settings", label: "Settings", icon: "⚙" },
];

export default function AdminSidebar() {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside className={`admin-sidebar transition-all duration-300 ${collapsed ? "w-16" : "w-64"}`}>
      <div className="flex items-center justify-between mb-8">
        {!collapsed && (
          <Link href="/admin" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center font-bold text-white text-sm">S</div>
            <span className="font-bold text-sm gradient-text">ADMIN</span>
          </Link>
        )}
        <button onClick={() => setCollapsed(!collapsed)} className="text-text-muted hover:text-foreground p-1">
          {collapsed ? "→" : "←"}
        </button>
      </div>

      <nav className="space-y-1">
        {menuItems.map((item) => {
          const isActive = pathname === item.href || (item.href !== "/admin" && pathname?.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${
                isActive
                  ? "bg-primary/20 text-primary-light"
                  : "text-text-muted hover:text-foreground hover:bg-surface-light"
              }`}
              title={collapsed ? item.label : undefined}
            >
              <span className="text-base flex-shrink-0">{item.icon}</span>
              {!collapsed && <span>{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      <div className="mt-8 pt-4 border-t border-border">
        <Link href="/" target="_blank" className="flex items-center gap-2 text-xs text-text-muted hover:text-accent px-3">
          {!collapsed && "View Website →"}
          {collapsed && "↗"}
        </Link>
      </div>
    </aside>
  );
}

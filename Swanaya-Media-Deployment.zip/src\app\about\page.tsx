import type { Metadata } from "next";
import ScrollReveal from "@/components/ScrollReveal";
import Breadcrumbs from "@/components/Breadcrumbs";
import { getSettings } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "About",
  description: "Learn about Swanaya Media Enterprises — a Kerala-based digital media company creating brands, building experiences and growing businesses globally.",
};

export default function AboutPage() {
  const settings = getSettings();

  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "About" }]} />

        <ScrollReveal>
          <div className="max-w-4xl py-12">
            <span className="text-accent text-sm font-semibold uppercase tracking-wider">About Swanaya</span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mt-2 mb-6">
              Creating Brands.<br />
              Building Experiences.<br />
              <span className="gradient-text">Growing Businesses.</span>
            </h1>
            <p className="text-text-muted text-lg leading-relaxed">
              {settings.description || "Swanaya Media Enterprises provides digital media, marketing, branding, technology, web development and business-growth solutions for organizations, brands and entrepreneurs."}
            </p>
          </div>
        </ScrollReveal>
      </div>

      <section className="py-24 bg-surface">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <ScrollReveal>
              <span className="text-accent text-sm font-semibold uppercase tracking-wider">Our Mission</span>
              <h2 className="text-3xl font-bold mt-2 mb-6">Empowering Businesses Through Digital Excellence</h2>
              <p className="text-text-muted leading-relaxed mb-4">
                Swanaya Media Enterprises exists to help organizations harness the full potential of digital media and technology. We believe every brand deserves a world-class digital presence, regardless of its size or location.
              </p>
              <p className="text-text-muted leading-relaxed">
                Based in Kerala, India, we bring a unique perspective that combines local understanding with global standards. Our team combines creative vision with technical expertise to deliver solutions that are both beautiful and effective.
              </p>
            </ScrollReveal>
            <ScrollReveal delay={200}>
              <span className="text-accent text-sm font-semibold uppercase tracking-wider">Our Vision</span>
              <h2 className="text-3xl font-bold mt-2 mb-6">To Be the Preferred Digital Partner for Growing Brands</h2>
              <p className="text-text-muted leading-relaxed mb-4">
                We envision a future where every business, regardless of its geographic location, has access to premium digital solutions. Swanaya Media Enterprises is building the infrastructure, expertise and creative capacity to make this vision a reality.
              </p>
              <p className="text-text-muted leading-relaxed">
                Through continuous innovation, strategic thinking and a relentless focus on results, we aim to be the digital headquarters for brands that want to grow.
              </p>
            </ScrollReveal>
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <ScrollReveal>
            <div className="text-center mb-16">
              <h2 className="text-3xl sm:text-4xl font-bold">
                Our <span className="gradient-text">Values</span>
              </h2>
            </div>
          </ScrollReveal>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { title: "Excellence", desc: "We pursue the highest standards in everything we create, ensuring premium quality at every touchpoint.", icon: "★" },
              { title: "Innovation", desc: "We embrace new technologies and creative approaches to stay ahead of the digital curve.", icon: "◆" },
              { title: "Integrity", desc: "We build relationships based on transparency, honesty and genuine care for our clients' success.", icon: "●" },
              { title: "Impact", desc: "We measure our success by the tangible results we deliver for our clients' businesses.", icon: "▲" },
            ].map((value, i) => (
              <ScrollReveal key={value.title} delay={i * 100}>
                <div className="card-glass rounded-2xl p-6 text-center">
                  <div className="text-3xl text-accent mb-4">{value.icon}</div>
                  <h3 className="text-xl font-bold text-foreground mb-2">{value.title}</h3>
                  <p className="text-sm text-text-muted">{value.desc}</p>
                </div>
              </ScrollReveal>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}

import CMSList from "@/components/admin/CMSList";

const columns = [
  { key: "platform", label: "Platform", type: "select", options: ["instagram", "facebook", "youtube", "linkedin", "twitter", "tiktok"] },
  { key: "url", label: "URL" },
  { key: "title", label: "Title" },
  { key: "sort_order", label: "Sort Order", type: "number" },
  { key: "published", label: "Published", boolean: true },
];

export default function AdminSocialPage() {
  return <CMSList type="social_links" columns={columns} displayName="Social Links" />;
}

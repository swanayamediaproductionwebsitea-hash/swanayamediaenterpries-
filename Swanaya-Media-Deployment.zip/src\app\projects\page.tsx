import type { Metadata } from "next";
import ScrollReveal from "@/components/ScrollReveal";
import ProjectCard from "@/components/ProjectCard";
import Breadcrumbs from "@/components/Breadcrumbs";
import { getProjects } from "@/lib/queries";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Projects",
  description: "Explore Swanaya Media Enterprises' portfolio of projects across digital marketing, web development, branding and more.",
};

export default function ProjectsPage() {
  const projects = getProjects() as { id: string; title: string; slug: string; short_description: string; client: string; category: string }[];

  return (
    <div className="pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Breadcrumbs items={[{ label: "Home", href: "/" }, { label: "Projects" }]} />
        <ScrollReveal>
          <div className="max-w-4xl py-12">
            <span className="text-accent text-sm font-semibold uppercase tracking-wider">Our Work</span>
            <h1 className="text-4xl sm:text-5xl font-bold mt-2 mb-6">
              Featured <span className="gradient-text">Projects</span>
            </h1>
            <p className="text-text-muted text-lg">
              A showcase of our work across digital marketing, web development, branding and creative solutions.
            </p>
          </div>
        </ScrollReveal>
      </div>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {projects.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {projects.map((project, i) => (
                <ScrollReveal key={project.id} delay={i * 100}>
                  <ProjectCard {...project} />
                </ScrollReveal>
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <p className="text-text-muted text-lg">Projects coming soon. Check back later.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

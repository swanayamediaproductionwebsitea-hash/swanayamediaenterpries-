import getDb from "@/lib/db";

export function getSettings(): Record<string, string> {
  const db = getDb();
  const rows = db.prepare("SELECT key, value FROM settings").all() as { key: string; value: string }[];
  const settings: Record<string, string> = {};
  for (const row of rows) settings[row.key] = row.value;
  return settings;
}

export function getServices() {
  const db = getDb();
  return db.prepare("SELECT * FROM services WHERE published = 1 ORDER BY sort_order ASC, created_at DESC").all();
}

export function getServiceBySlug(slug: string) {
  const db = getDb();
  return db.prepare("SELECT * FROM services WHERE slug = ? AND published = 1").get(slug);
}

export function getAllServices() {
  const db = getDb();
  return db.prepare("SELECT * FROM services ORDER BY sort_order ASC").all();
}

export function getProjects() {
  const db = getDb();
  return db.prepare("SELECT * FROM projects WHERE published = 1 ORDER BY created_at DESC").all();
}

export function getProjectBySlug(slug: string) {
  const db = getDb();
  return db.prepare("SELECT * FROM projects WHERE slug = ? AND published = 1").get(slug);
}

export function getProducts() {
  const db = getDb();
  return db.prepare("SELECT * FROM products WHERE published = 1 ORDER BY created_at DESC").all();
}

export function getProductBySlug(slug: string) {
  const db = getDb();
  return db.prepare("SELECT * FROM products WHERE slug = ? AND published = 1").get(slug);
}

export function getTeam() {
  const db = getDb();
  return db.prepare("SELECT * FROM team WHERE published = 1 ORDER BY sort_order ASC").all();
}

export function getTeamBySlug(slug: string) {
  const db = getDb();
  return db.prepare("SELECT * FROM team WHERE slug = ? AND published = 1").get(slug);
}

export function getBlogPosts() {
  const db = getDb();
  return db.prepare("SELECT b.*, t.name as author_name, t.avatar as author_avatar FROM blog b LEFT JOIN team t ON b.author_id = t.id WHERE b.published = 1 ORDER BY b.published_at DESC, b.created_at DESC").all();
}

export function getBlogBySlug(slug: string) {
  const db = getDb();
  return db.prepare("SELECT b.*, t.name as author_name, t.avatar as author_avatar, t.slug as author_slug FROM blog b LEFT JOIN team t ON b.author_id = t.id WHERE b.slug = ? AND b.published = 1").get(slug);
}

export function getFaqs(category?: string) {
  const db = getDb();
  if (category) {
    return db.prepare("SELECT * FROM faqs WHERE published = 1 AND category = ? ORDER BY sort_order ASC").all(category);
  }
  return db.prepare("SELECT * FROM faqs WHERE published = 1 ORDER BY sort_order ASC").all();
}

export function getSocialLinks() {
  const db = getDb();
  return db.prepare("SELECT * FROM social_links WHERE published = 1 ORDER BY sort_order ASC").all();
}

export function getPages() {
  const db = getDb();
  return db.prepare("SELECT * FROM pages WHERE published = 1").all();
}

export function getPageBySlug(slug: string) {
  const db = getDb();
  return db.prepare("SELECT * FROM pages WHERE slug = ? AND published = 1").get(slug);
}

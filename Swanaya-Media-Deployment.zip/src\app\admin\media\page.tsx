import CMSList from "@/components/admin/CMSList";

const columns = [
  { key: "filename", label: "Filename" },
  { key: "url", label: "URL" },
  { key: "alt", label: "Alt Text" },
  { key: "caption", label: "Caption" },
  { key: "folder", label: "Folder" },
  { key: "mime_type", label: "MIME Type" },
];

export default function AdminMediaPage() {
  return <CMSList type="media" columns={columns} displayName="Media Library" />;
}

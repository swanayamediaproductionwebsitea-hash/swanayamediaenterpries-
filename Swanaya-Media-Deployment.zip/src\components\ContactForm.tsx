"use client";

import { useState } from "react";
import { trackEvent } from "@/lib/analytics-client";

interface Props {
  services?: string[];
}

export default function ContactForm({ services = [] }: Props) {
  const [form, setForm] = useState({ name: "", email: "", phone: "", company: "", service: "", message: "" });
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("sending");
    trackEvent("contact_form_submitted", { service: form.service });

    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, source: "website" }),
      });
      if (res.ok) {
        setStatus("success");
        setForm({ name: "", email: "", phone: "", company: "", service: "", message: "" });
      } else {
        setStatus("error");
      }
    } catch {
      setStatus("error");
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    trackEvent("contact_form_started");
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  if (status === "success") {
    return (
      <div className="card-glass rounded-2xl p-12 text-center">
        <div className="text-4xl mb-4">✓</div>
        <h3 className="text-2xl font-bold text-foreground mb-2">Thank You!</h3>
        <p className="text-text-muted">We have received your message and will get back to you within 24 hours.</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="card-glass rounded-2xl p-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Name *</label>
          <input type="text" name="name" required value={form.name} onChange={handleChange} className="input-field" placeholder="Your name" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Email *</label>
          <input type="email" name="email" required value={form.email} onChange={handleChange} className="input-field" placeholder="your@email.com" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Phone</label>
          <input type="tel" name="phone" value={form.phone} onChange={handleChange} className="input-field" placeholder="+91 XXXXX XXXXX" />
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">Company</label>
          <input type="text" name="company" value={form.company} onChange={handleChange} className="input-field" placeholder="Your company" />
        </div>
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-foreground mb-2">Service Interest</label>
          <select name="service" value={form.service} onChange={handleChange} className="input-field">
            <option value="">Select a service</option>
            {services.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
            <option value="general">General Enquiry</option>
          </select>
        </div>
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-foreground mb-2">Message</label>
          <textarea name="message" value={form.message} onChange={handleChange} rows={5} className="input-field resize-none" placeholder="Tell us about your project or requirements..." />
        </div>
      </div>
      <button type="submit" disabled={status === "sending"} className="btn-primary mt-6 w-full disabled:opacity-50">
        {status === "sending" ? "Sending..." : "Send Message"}
      </button>
      {status === "error" && <p className="text-red-400 text-sm mt-2">Something went wrong. Please try again.</p>}
    </form>
  );
}
